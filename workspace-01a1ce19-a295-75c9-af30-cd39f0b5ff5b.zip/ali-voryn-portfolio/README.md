# Ali Voryn Portfolio

Next.js App Router + React + TypeScript + Tailwind CSS foundation for the portfolio.

## Commands

- `npm run dev` — start the development server on `0.0.0.0:3000`.
- `npm run build` — create a production build.
- `npm run start` — serve the production build.
- `npm run lint` — run ESLint.
- `npm run typecheck` — run TypeScript without emitting files.

Node.js 20.9+ is required.

## Structure

```text
.
├── docs/
│   ├── DESIGN_NOTES.md          Design rules to follow in future changes (Persian)
│   └── design-references/       Reference screenshots (not used at runtime)
├── public/                      Static files, served as they are
│   ├── brand/                   The signature: ali-voryn-signature.gif (3 s loop) + .png (still frame)
│   ├── courses/thumbnails/      Course cover images, one per course (WebP, 1280×720)
│   ├── instructors/             Instructor profile photos (square WebP, 256×256)
│   └── fonts/                   Self-hosted fonts: Noto Kufi Arabic (text), Estedad (titles), Vazir (numbers) + OFL licenses
├── src/
│   ├── app/                     ROUTES ONLY (App Router)
│   │   ├── layout.tsx           Root layout: <html>, metadata, fonts
│   │   ├── page.tsx             Home page: puts the sections together
│   │   ├── loading.tsx          Loading screen
│   │   ├── globals.css          Design tokens (colours, fonts, spacing) and base styles
│   │   ├── icon.svg             Favicon
│   │   └── _components/         Pieces that belong to this route only (a "_" folder is never a URL)
│   │       ├── PortfolioSections.tsx   The sections under the hero
│   │       └── PortfolioEffects.tsx    The single client entry point that starts every behaviour
│   ├── components/              SHARED UI, used by any page; knows nothing about courses
│   │   ├── brand/               BrandLogo (monogram + signature GIF), BrandMark
│   │   ├── layout/              SiteHeader, SiteSettings (gear: language + theme; site-settings.css), mobile-menu, scribble-loop (menu hover)
│   │   └── ui/                  Generic building blocks; each folder holds the component, its CSS and its behaviour
│   │       ├── carousel/        Carousel + headless useCarousel hook
│   │       ├── filter-tabs/     FilterTabs (pill-shaped tab list)
│   │       ├── floating-dock/   FloatingDock (floating corner button with a drawer)
│   │       ├── glass-icon/      GlassIcon (glass-style icons: gear, cart)
│   │       ├── reveal/          Scroll reveal (data-reveal="start|end|fade")
│   │       ├── section-dots/    SectionDots (dots navigation at the window edge)
│   │       └── section-title/   SectionTitle (accent first word + rocket underline)
│   ├── features/                ONE FOLDER PER PRODUCT AREA: its components, data and behaviour together
│   │   ├── about/               globe-mesh, spotlight-text
│   │   ├── courses/             components/ (CourseShowcase, CourseCard, CoursePrice), courses.data.ts, types, strings, select event
│   │   ├── hero/                HeroSection, typewriter-glitch (headline), code-window + code-samples, hero-stats
│   │   ├── search/              CourseSearchDialog, course-search
│   │   └── theme/               ThemeDialog, theme-language (colour theme + language switch)
│   ├── config/                  Site-wide constants: sections.ts (home-page sections and their titles)
│   ├── hooks/                   Shared React hooks: use-locale
│   └── lib/                     Framework-free helpers
│       └── effects/             Page-wide canvases: ascii-rain, cursor-ring
├── eslint.config.mjs
├── next.config.mjs
├── postcss.config.mjs
├── tailwind.config.ts
├── tsconfig.json                `@/*` resolves to `src/*`
├── package.json
└── package-lock.json
```

Generated files are not committed: `node_modules/`, `.next/`, `next-env.d.ts` and `*.tsbuildinfo` are recreated by `npm ci` and `npm run dev` / `npm run build`.

Where a new file goes:

| It is… | It goes in… |
| --- | --- |
| a page or a URL | `src/app/<route>/page.tsx` |
| used by that one page only | `src/app/<route>/_components/` |
| UI that any page may use | `src/components/ui/<name>/` (component + CSS + behaviour together) |
| part of one product area (courses, search, …) | `src/features/<area>/` |
| a constant, a shared hook, a plain helper | `src/config/`, `src/hooks/`, `src/lib/` |

Imports use the `@/` alias (`@/features/courses/…`); only files in the same folder are imported with `./`. `features` may import from `components`, `hooks`, `lib` and `config`, never the other way round.

Add route segments under `src/app` (for example, `src/app/projects/page.tsx`) and reusable UI under `src/components`. Keep browser-only state and APIs inside small Client Components; prefer Server Components for static content. Put feature-specific logic under `src/features/<feature>` and avoid placing page-specific code in the root layout.

The current canvas and legacy DOM interactions are isolated in `PortfolioEffects` and imported from feature folders so the UI can be migrated incrementally to idiomatic React hooks/components without mixing them into server-rendered page markup.

## Courses

All course content lives in `src/features/courses/courses.data.ts`: the category list (in filter order) and the courses. The courses section and the course search both read from it, so adding a course is one new object in `COURSES` plus a cover image in `public/courses/thumbnails/`. The instructor shown on the cards (name, initials and the photo in `public/instructors/`) is the `INSTRUCTOR` constant in the same file; without a photo the card falls back to the initials. A category without courses shows a "coming soon" note; pass `hideEmptyCategories` to `CourseShowcase` to leave such categories out of the filter instead.

The pieces are independent and reusable:

- `Carousel` (`src/components/ui/carousel`) takes any `items` and a `renderItem` function. It loops endlessly, plays automatically every 4 seconds (`autoplayInterval`; paused on hover, keyboard focus, when off-screen and for reduced motion), supports drag/swipe, arrow keys, arrows and dots, and follows the reading direction. Slide width and gap are the CSS variables `--carousel-slide-width` and `--carousel-gap`. `useCarousel` is the same engine without markup.
- `FilterTabs` (`src/components/ui/filter-tabs`) is a controlled, accessible tab list: `tabs`, `value`, `onChange`.
- `CourseCard` renders one `Course` in a given language and can be used on its own, outside a carousel.
- `selectCourse(id)` (`src/features/courses/course-events.ts`) asks the courses section to scroll to and highlight a course; the search dialog uses it.

## Reusable pieces

Each of these is used by adding one element; none of them knows about the page it is on.

- **Signature** — the name beside the logo is a 3-second looping GIF, `public/brand/ali-voryn-signature.gif` (white ink on black, 303×93). `src/components/brand/brand.css` uses it as a brightness mask over a strip in the theme colours, so the ink follows the colour theme and sits on any background; with reduced motion the still frame (`.png`) is shown. To replace it, put another GIF of the same proportions in its place; no code changes.
- **Scroll reveal** — add `data-reveal="start"`, `"end"` or `"fade"` to any element: it stays hidden until it is scrolled into view, comes in from that side (elements arriving together one after another), leaves when it is scrolled away and comes in again on the way back. For content that is swapped at runtime (the course carousel), put `data-reveal-group` on a wrapper that stays mounted and `data-reveal-item` on the items. `initScrollReveal(root?)` can be called again for elements added later. With reduced motion, in print and without JavaScript nothing is hidden.
- **Section dots** — `<SectionDots sections={HOME_SECTIONS} showAfter="home" ariaLabel="…" />` (`src/components/ui/section-dots`) is the dots navigation fixed to the end edge of the window: right in Persian, left in English. The lit dot is the section that fills most of the window, and the dots slide in from their own edge as soon as that section is no longer `showAfter`. They do not exist below 1024px of width. The sections of the home page live in `src/features/navigation/sections.data.ts`; the header links and the section titles are built from the same list, so a new section is one new entry there.
- **Section title** — `<SectionTitle lead={{ fa, en }} rest={{ fa, en }} />` (`src/components/ui/section-title`) is a section heading whose first word takes the theme's main colour, with a line that shoots under it like a rocket from the first letter to the end of the word, fades and starts again every 3 seconds (`--section-title-period`). `sectionTitle(id)` returns the props for a home-page section. Options: `as`, `reveal`, `className`.
- **Glass icon** — `<GlassIcon name="gear" />` or `"cart"` (`src/components/ui/glass-icon`) draws a glass-style icon, 1em in size, coloured by the active theme (`--glass-icon-from`, `--glass-icon-to` override it). New icons are added in `GlassIcon.tsx`.
- **Floating dock** — `<FloatingDock id="…" icon={…} label={{ fa, en }}>…controls…</FloatingDock>` (`src/components/ui/floating-dock`) is a softly floating, slowly turning round button fixed to the bottom corner (left in Persian, right in English). Hover, keyboard focus or a tap slides a small drawer up above it; Escape or a click elsewhere closes it, and a control marked `data-dock-close` closes it when used. `SiteSettings` uses it for the language and theme buttons.
- **Carousel**, **FilterTabs**, **CourseCard** — see Courses above.

## Typography

The site uses three self-hosted families (all SIL OFL 1.1, in `public/fonts/`), each with one job. They are named in one place only — the top of `src/app/globals.css`:

| Variable | Family | Used for |
| --- | --- | --- |
| `--font-body` | Noto Kufi Arabic | running text, menus, buttons, course cards |
| `--font-display` | Estedad | the main title of each section and the typed headline of the opening header |
| `--font-number` | Vazir | numbers: stats, prices, student counts, ratings |
| `--font-mono` | IBM Plex Mono stack | the hero code window and colour codes |

A digit typed anywhere in ordinary text is also set in Vazir with no extra markup: `--font-body` starts with "Vazir Digits", which is Vazir limited by `unicode-range` to digits and the Persian separators.

To change a typeface, add its `@font-face` there and edit these variables; no other file names a font (Tailwind's `font-sans`, `font-heading`, `font-number` and `font-mono` point at the same variables). The header signature is SVG path data and does not depend on any of them.

## Security and operations

- React escapes interpolated text by default; do not introduce `dangerouslySetInnerHTML` for user-provided content.
- Keep secrets in environment variables and out of client components.
- Use same-origin relative URLs for future browser-facing API calls.
- Basic security response headers are configured in `next.config.mjs`; no permissive remote image domains or public secrets are configured.
