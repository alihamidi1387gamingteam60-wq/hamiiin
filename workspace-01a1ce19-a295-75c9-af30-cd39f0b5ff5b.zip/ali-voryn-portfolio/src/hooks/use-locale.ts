'use client';

import { useSyncExternalStore } from 'react';

export type Language = 'fa' | 'en';
export type Direction = 'rtl' | 'ltr';
export type Localized<T = string> = Record<Language, T>;

/**
 * The language switch (see theme-language.js) writes `lang` and `dir` on
 * <html>. Observing those attributes keeps React components in sync with it
 * without coupling them to the switch's implementation.
 */
function subscribe(onChange: () => void) {
  const observer = new MutationObserver(onChange);
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['lang', 'dir'] });
  return () => observer.disconnect();
}

const getLanguage = (): Language => (document.documentElement.lang === 'en' ? 'en' : 'fa');
const getServerLanguage = (): Language => 'fa';

/** Current UI language and reading direction, updated live when the user switches language. */
export function useLocale(): { language: Language; direction: Direction } {
  const language = useSyncExternalStore(subscribe, getLanguage, getServerLanguage);
  return { language, direction: language === 'fa' ? 'rtl' : 'ltr' };
}
