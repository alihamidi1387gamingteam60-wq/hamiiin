import { COURSE_STRINGS, discountedPrice, formatNumber, formatPercent } from '@/features/courses/courses.i18n';
import type { Course } from '@/features/courses/types';
import type { Language } from '@/hooks/use-locale';

interface CoursePriceProps {
  price: Course['price'];
  discountPercent: Course['discountPercent'];
  language: Language;
}

/** Price block of a course card: list price, discount badge and the price to pay (or "Free"). */
export function CoursePrice({ price, discountPercent, language }: CoursePriceProps) {
  const discounted = discountPercent > 0 && price > 0;
  const finalPrice = discountedPrice(price, discountPercent);
  const free = finalPrice === 0;

  return (
    <div className="course-price" data-discounted={discounted}>
      {discounted && (
        <s className="course-price__list">
          <span className="visually-hidden">{COURSE_STRINGS.listPrice[language]}: </span>
          {formatNumber(price, language)}
        </s>
      )}
      {discounted && <span className="course-price__badge">{formatPercent(discountPercent, language)}</span>}
      <strong className="course-price__final">
        <span className="visually-hidden">{COURSE_STRINGS.price[language]}: </span>
        {free ? COURSE_STRINGS.free[language] : (
          <>
            <span className="course-price__amount">{formatNumber(finalPrice, language)}</span>
            <span className="course-price__currency">{COURSE_STRINGS.currency[language]}</span>
          </>
        )}
      </strong>
      {discounted && <span className="course-price__discount-label">{COURSE_STRINGS.discount[language]}</span>}
    </div>
  );
}
