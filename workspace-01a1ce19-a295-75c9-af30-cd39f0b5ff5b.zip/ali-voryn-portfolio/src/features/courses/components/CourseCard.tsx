import Image from 'next/image';
import { COURSE_STRINGS, formatNumber } from '@/features/courses/courses.i18n';
import type { Course } from '@/features/courses/types';
import type { Language } from '@/hooks/use-locale';
import { CoursePrice } from './CoursePrice';
import './course-card.css';

export interface CourseCardProps {
  course: Course;
  language: Language;
  /** Decorative duplicate (e.g. a carousel clone): hidden from assistive tech and not focusable. */
  decorative?: boolean;
  /** Draws attention to the card, e.g. after it was picked from search. */
  highlighted?: boolean;
  /** `sizes` hint for the thumbnail; defaults suit a card of roughly 280–360px. */
  imageSizes?: string;
}

/** Course card: thumbnail, title, two-line summary, instructor, rating, students and price. */
export function CourseCard({
  course,
  language,
  decorative = false,
  highlighted = false,
  imageSizes = '(max-width: 680px) 85vw, 360px'
}: CourseCardProps) {
  const title = course.title[language];
  const strings = COURSE_STRINGS;

  return (
    <article className="course-card" data-course-id={decorative ? undefined : course.id} data-highlighted={highlighted || undefined}>
      <div className="course-card__media">
        <Image
          className="course-card__image"
          src={course.thumbnail.src}
          alt={decorative ? '' : course.thumbnail.alt[language]}
          width={course.thumbnail.width}
          height={course.thumbnail.height}
          sizes={imageSizes}
          draggable={false}
        />
      </div>

      <div className="course-card__body">
        <h3 className="course-card__title">
          {course.href
            ? <a className="course-card__link" href={course.href} tabIndex={decorative ? -1 : undefined}>{title}</a>
            : title}
        </h3>
        <p className="course-card__summary">{course.summary[language]}</p>

        <div className="course-card__meta">
          <span className="course-card__instructor">
            <span className="course-card__avatar" aria-hidden="true">
              {course.instructor.avatar
                ? <Image className="course-card__avatar-image" src={course.instructor.avatar} alt="" width={64} height={64} sizes="32px" draggable={false} />
                : course.instructor.initials}
            </span>
            <span className="visually-hidden">{strings.instructor[language]}: </span>
            {course.instructor.name[language]}
          </span>
          <span className="course-card__rating">
            <span className="visually-hidden">{strings.rating[language]}: </span>
            {formatNumber(course.rating, language)}
            <svg className="course-card__star" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 2.6l2.75 5.9 6.45.8-4.75 4.45 1.25 6.4L12 16.95 6.3 20.15l1.25-6.4L2.8 9.3l6.45-.8z" />
            </svg>
          </span>
        </div>

        <div className="course-card__footer">
          <span className="course-card__students">
            <svg className="course-card__icon" viewBox="0 0 24 24" aria-hidden="true">
              <circle cx="12" cy="8" r="3.6" />
              <path d="M4.8 20.2v-.9a7.2 7.2 0 0 1 14.4 0v.9" />
            </svg>
            {formatNumber(course.students, language)}
            <span className="visually-hidden"> {strings.students[language]}</span>
          </span>
          <CoursePrice price={course.price} discountPercent={course.discountPercent} language={language} />
        </div>
      </div>
    </article>
  );
}
