'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Carousel } from '@/components/ui/carousel/Carousel';
import type { CarouselHandle, CarouselLabels } from '@/components/ui/carousel/Carousel';
import { FilterTabs, filterTabId } from '@/components/ui/filter-tabs/FilterTabs';
import { COURSE_SELECT_EVENT } from '@/features/courses/course-events';
import type { CourseSelectDetail } from '@/features/courses/course-events';
import { COURSE_STRINGS, slidePosition } from '@/features/courses/courses.i18n';
import { initScrollReveal } from '@/components/ui/reveal/scroll-reveal.js';
import { ALL_CATEGORIES } from '@/features/courses/types';
import type { Course, CourseCategory } from '@/features/courses/types';
import { useLocale } from '@/hooks/use-locale';
import { CourseCard } from './CourseCard';
import './course-showcase.css';

export interface CourseShowcaseProps {
  courses: readonly Course[];
  categories: readonly CourseCategory[];
  /** Unique prefix for element ids, so several showcases can share a page. */
  id?: string;
  /** Milliseconds between automatic slides; `0` turns autoplay off. */
  autoplayInterval?: number;
  /** Leave categories that have no courses out of the filter. */
  hideEmptyCategories?: boolean;
}

const HIGHLIGHT_MS = 2000;

/**
 * Category filter plus a looping carousel of course cards. Picking a category
 * swaps in that category's own carousel. Also reveals a course when another
 * part of the page asks for it through `selectCourse()`.
 */
export function CourseShowcase({
  courses,
  categories,
  id = 'courses',
  autoplayInterval = 4000,
  hideEmptyCategories = false
}: CourseShowcaseProps) {
  const { language, direction } = useLocale();
  const [categoryId, setCategoryId] = useState(ALL_CATEGORIES);
  const [reveal, setReveal] = useState<{ courseId: string } | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const carouselRef = useRef<CarouselHandle>(null);
  const panelId = `${id}-panel`;

  const tabs = useMemo(() => [
    { id: ALL_CATEGORIES, label: COURSE_STRINGS.allCategories[language] },
    ...categories
      .filter(category => !hideEmptyCategories || courses.some(course => course.categoryId === category.id))
      .map(category => ({ id: category.id, label: category.label[language] }))
  ], [categories, courses, hideEmptyCategories, language]);

  const visibleCourses = useMemo(
    () => (categoryId === ALL_CATEGORIES ? courses : courses.filter(course => course.categoryId === categoryId)),
    [categoryId, courses]
  );

  const carouselLabels = useMemo<CarouselLabels>(() => ({
    previous: COURSE_STRINGS.previous[language],
    next: COURSE_STRINGS.next[language],
    position: (position, total) => slidePosition(position, total, language)
  }), [language]);

  // A course requested from elsewhere (course search): switch to "All" and remember the request…
  useEffect(() => {
    const onSelect = (event: Event) => {
      const courseId = (event as CustomEvent<CourseSelectDetail>).detail?.id;
      if (!courses.some(course => course.id === courseId)) return;
      setCategoryId(ALL_CATEGORIES);
      setReveal({ courseId });
    };
    document.addEventListener(COURSE_SELECT_EVENT, onSelect);
    return () => document.removeEventListener(COURSE_SELECT_EVENT, onSelect);
  }, [courses]);

  // …then, once the "All" carousel is on screen, slide to the card, scroll it into view and highlight it briefly.
  useEffect(() => {
    if (!reveal) return;
    carouselRef.current?.goTo(courses.findIndex(course => course.id === reveal.courseId));
    rootRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const timer = window.setTimeout(() => setReveal(null), HIGHLIGHT_MS);
    return () => window.clearTimeout(timer);
  }, [courses, reveal]);

  // The showcase may mount after the page-wide reveal pass: register its own elements (safe to repeat).
  useEffect(() => {
    if (rootRef.current) initScrollReveal(rootRef.current);
  }, []);

  return (
    <div className="course-showcase" ref={rootRef}>
      <div className="course-showcase__filters" data-reveal="start">
        <FilterTabs
          tabs={tabs}
          value={categoryId}
          onChange={setCategoryId}
          ariaLabel={COURSE_STRINGS.categoriesLabel[language]}
          idPrefix={id}
          panelId={panelId}
        />
      </div>

      {/* Scroll reveal: this wrapper stays mounted across categories, the cards inside come in one after another. */}
      <div className="course-showcase__stage" data-reveal="fade" data-reveal-group>
        {/* Keyed by category: each category gets its own carousel, starting from its first course. */}
        <div
          className="course-showcase__panel"
          role="tabpanel"
          id={panelId}
          aria-labelledby={filterTabId(id, categoryId)}
          key={categoryId}
        >
          {visibleCourses.length > 0 ? (
            <Carousel
              ref={carouselRef}
              className="course-showcase__carousel"
              items={visibleCourses}
              getKey={course => course.id}
              renderItem={(course, { isClone }) => (
                <div data-reveal-item="end">
                  <CourseCard
                    course={course}
                    language={language}
                    decorative={isClone}
                    highlighted={course.id === reveal?.courseId}
                  />
                </div>
              )}
              ariaLabel={COURSE_STRINGS.carouselLabel[language]}
              labels={carouselLabels}
              direction={direction}
              autoplayInterval={autoplayInterval}
            />
          ) : (
            <p className="course-showcase__empty">{COURSE_STRINGS.empty[language]}</p>
          )}
        </div>
      </div>
    </div>
  );
}
