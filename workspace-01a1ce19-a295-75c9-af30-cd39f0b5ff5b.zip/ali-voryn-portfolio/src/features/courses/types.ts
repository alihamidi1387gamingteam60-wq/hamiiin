import type { Localized } from '@/hooks/use-locale';

export const ALL_CATEGORIES = 'all';

export interface CourseCategory {
  id: string;
  label: Localized;
}

export interface Course {
  id: string;
  /** Must match a `CourseCategory.id`. */
  categoryId: string;
  title: Localized;
  /** Short description; the card shows two lines of it. */
  summary: Localized;
  thumbnail: {
    /** Path under `public/`. */
    src: string;
    width: number;
    height: number;
    alt: Localized;
  };
  instructor: {
    name: Localized;
    /** Shown in the round avatar when there is no photo. */
    initials: string;
    /** Square photo, path under `public/`. */
    avatar?: string;
  };
  /** 0–5. */
  rating: number;
  students: number;
  /** List price in Toman. */
  price: number;
  /** 0–100. `100` renders the course as free. */
  discountPercent: number;
  /** Extra search terms that are not already in the title or summary. */
  keywords: readonly string[];
  /** Optional course page; when omitted the card is not a link. */
  href?: string;
}
