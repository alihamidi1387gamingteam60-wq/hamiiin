import type { Course, CourseCategory } from './types';

/**
 * Course catalogue. This file is the single source for the courses section and
 * for course search — add, remove or edit courses and categories here.
 *
 * Categories appear in the filter in this order, after "All". A category with
 * no courses yet shows a short "coming soon" note instead of a carousel.
 */
export const COURSE_CATEGORIES: readonly CourseCategory[] = [
  { id: 'ai', label: { fa: 'هوش مصنوعی', en: 'Artificial Intelligence' } },
  { id: 'programming', label: { fa: 'برنامه‌نویسی', en: 'Programming' } },
  { id: 'languages', label: { fa: 'زبان‌های خارجی', en: 'Foreign Languages' } },
  { id: 'business', label: { fa: 'مدیریت و کسب و کار', en: 'Business & Management' } },
  { id: 'finance', label: { fa: 'مالی و سرمایه‌گذاری', en: 'Finance & Investing' } },
  { id: 'security', label: { fa: 'هک و امنیت', en: 'Hacking & Security' } },
  { id: 'life-skills', label: { fa: 'مهارت‌های زندگی', en: 'Life Skills' } },
  { id: 'art', label: { fa: 'هنر', en: 'Art' } }
];

const INSTRUCTOR = {
  name: { fa: 'Ali Voryn', en: 'Ali Voryn' },
  initials: 'AV',
  avatar: '/instructors/ali-voryn.webp'
} as const;
const THUMBNAIL_SIZE = { width: 1280, height: 720 } as const;

export const COURSES: readonly Course[] = [
  {
    id: 'solidity-expert',
    categoryId: 'programming',
    title: { fa: 'دوره متخصص Solidity', en: 'Solidity Expert' },
    summary: {
      fa: 'از مبانی بلاکچین و ماشین مجازی اتریوم تا نوشتن، تست، امن‌سازی و دیپلوی قراردادهای هوشمند واقعی با Solidity؛ مسیری پروژه‌محور برای ورود حرفه‌ای به دنیای Web3.',
      en: 'From blockchain and EVM fundamentals to writing, testing, securing and deploying real smart contracts with Solidity — a project-based path into professional Web3 development.'
    },
    thumbnail: {
      src: '/courses/thumbnails/solidity.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص Solidity', en: 'Solidity Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 3250,
    price: 4_800_000,
    discountPercent: 30,
    keywords: ['سالیدیتی', 'قرارداد هوشمند', 'اتریوم', 'بلاکچین', 'وب۳', 'smart contract', 'ethereum', 'evm', 'web3', 'blockchain']
  },
  {
    id: 'ai-agent-expert',
    categoryId: 'ai',
    title: { fa: 'دوره متخصص AI Agent', en: 'AI Agent Expert' },
    summary: {
      fa: 'طراحی و ساخت ایجنت‌های هوش مصنوعی با TypeScript؛ از کار با مدل‌های زبانی، ابزارها و حافظه تا ساخت ایجنت‌های چندمرحله‌ای و آماده‌سازی آن‌ها برای محیط واقعی.',
      en: 'Design and build AI agents with TypeScript — from working with language models, tools and memory to multi-step agents that are ready for production.'
    },
    thumbnail: {
      src: '/courses/thumbnails/ai-agent.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص AI Agent', en: 'AI Agent Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 2140,
    price: 5_400_000,
    discountPercent: 0,
    keywords: ['ایجنت', 'عامل هوشمند', 'هوش مصنوعی', 'مدل زبانی', 'agents', 'llm', 'typescript', 'ai']
  },
  {
    id: 'typescript-expert',
    categoryId: 'programming',
    title: { fa: 'دوره متخصص TypeScript', en: 'TypeScript Expert' },
    summary: {
      fa: 'تایپ‌اسکریپت از پایه تا پیشرفته؛ سیستم تایپ، جنریک‌ها، تایپ‌های کاربردی و الگوهای حرفه‌ای برای نوشتن کدهای امن، خوانا و مقیاس‌پذیر در پروژه‌های واقعی.',
      en: 'TypeScript from the ground up to advanced — the type system, generics, utility types and professional patterns for safe, readable and scalable code in real projects.'
    },
    thumbnail: {
      src: '/courses/thumbnails/typescript.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص TypeScript', en: 'TypeScript Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 5870,
    price: 2_900_000,
    discountPercent: 40,
    keywords: ['تایپ اسکریپت', 'تایپ‌اسکریپت', 'جنریک', 'ts', 'generics', 'types']
  },
  {
    id: 'javascript-expert',
    categoryId: 'programming',
    title: { fa: 'دوره متخصص JavaScript', en: 'JavaScript Expert' },
    summary: {
      fa: 'جاوااسکریپت را عمیق و اصولی یاد بگیرید؛ از مفاهیم پایه و ES6+ تا برنامه‌نویسی ناهمگام، کار با DOM و ساخت پروژه‌های واقعی که شما را برای بازار کار آماده می‌کند.',
      en: 'Learn JavaScript in depth — from the fundamentals and ES6+ to asynchronous programming, the DOM and real projects that prepare you for the job market.'
    },
    thumbnail: {
      src: '/courses/thumbnails/javascript.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص JavaScript', en: 'JavaScript Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 12400,
    price: 1_500_000,
    discountPercent: 100,
    keywords: ['جاوا اسکریپت', 'جاوااسکریپت', 'js', 'es6', 'dom', 'async']
  },
  {
    id: 'python-expert',
    categoryId: 'programming',
    title: { fa: 'دوره متخصص Python', en: 'Python Expert' },
    summary: {
      fa: 'پایتون از صفر تا سطح حرفه‌ای؛ از سینتکس و ساختار داده‌ها تا شی‌گرایی، کار با فایل و API، اتوماسیون و ساخت پروژه‌های واقعی که مسیر بک‌اند، داده و هوش مصنوعی را برایتان باز می‌کند.',
      en: 'Python from zero to a professional level — syntax and data structures, object-oriented design, files and APIs, automation and real projects that open the door to backend, data and AI work.'
    },
    thumbnail: {
      src: '/courses/thumbnails/python.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص Python', en: 'Python Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 8430,
    price: 3_200_000,
    discountPercent: 25,
    keywords: ['پایتون', 'شی گرایی', 'اتوماسیون', 'py', 'oop', 'automation', 'backend']
  },
  {
    id: 'mba-expert',
    categoryId: 'business',
    title: { fa: 'دوره متخصص MBA', en: 'MBA Expert' },
    summary: {
      fa: 'مدیریت کسب‌وکار به زبان ساده و کاربردی؛ از استراتژی، بازاریابی و فروش تا مدیریت مالی، رهبری تیم و تصمیم‌گیری، با مثال‌ها و تمرین‌هایی برای ساختن و رشد دادن کسب‌وکار خودتان.',
      en: 'Business management made practical — strategy, marketing and sales, financial management, team leadership and decision-making, with examples and exercises for building and growing your own business.'
    },
    thumbnail: {
      src: '/courses/thumbnails/mba.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص MBA', en: 'MBA Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 1870,
    price: 6_900_000,
    discountPercent: 20,
    keywords: ['ام بی ای', 'مدیریت', 'کسب و کار', 'کسب‌وکار', 'بازاریابی', 'استراتژی', 'رهبری', 'business', 'management', 'marketing', 'strategy', 'leadership']
  },
  {
    id: 'penetration-testing-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص تست نفوذ', en: 'Penetration Testing Expert' },
    summary: {
      fa: 'تست نفوذ و هک اخلاقی از پایه تا حرفه‌ای؛ از مبانی شبکه و لینوکس تا شناسایی و ارزیابی آسیب‌پذیری‌ها، نفوذ کنترل‌شده به وب و شبکه و نوشتن گزارش امنیتی، در محیط‌های آزمایشگاهی و قانونی.',
      en: 'Penetration testing and ethical hacking from the basics to a professional level — networking and Linux foundations, vulnerability assessment, controlled exploitation of web and network targets and security reporting, all in legal lab environments.'
    },
    thumbnail: {
      src: '/courses/thumbnails/penetration-testing.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص تست نفوذ', en: 'Penetration Testing Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 2760,
    price: 5_900_000,
    discountPercent: 15,
    keywords: ['تست نفوذ', 'هک اخلاقی', 'امنیت', 'امنیت شبکه', 'آسیب پذیری', 'هک', 'pentest', 'ethical hacking', 'security', 'vulnerability', 'network security', 'exploitation']
  },
  {
    id: 'seo-expert',
    categoryId: 'business',
    title: { fa: 'دوره متخصص SEO', en: 'SEO Expert' },
    summary: {
      fa: 'سئو را اصولی و کامل یاد بگیرید؛ از تحقیق کلمات کلیدی و سئوی تکنیکال تا سئوی داخلی و خارجی، تحلیل رقبا و گزارش‌گیری، برای رساندن سایت به صفحهٔ اول گوگل و رشد ترافیک واقعی.',
      en: 'Learn SEO properly and completely — keyword research, technical SEO, on-page and off-page SEO, competitor analysis and reporting, to bring a site to the first page of Google and grow real traffic.'
    },
    thumbnail: {
      src: '/courses/thumbnails/seo.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص SEO', en: 'SEO Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 4310,
    price: 3_600_000,
    discountPercent: 35,
    keywords: ['سئو', 'بهینه سازی سایت', 'گوگل', 'کلمات کلیدی', 'رتبه', 'ترافیک', 'search engine optimization', 'google', 'keyword research', 'technical seo', 'on-page', 'off-page']
  },
  {
    id: 'digital-marketing-expert',
    categoryId: 'business',
    title: { fa: 'دوره متخصص Digital Marketing', en: 'Digital Marketing Expert' },
    summary: {
      fa: 'دیجیتال مارکتینگ از استراتژی تا اجرا؛ تولید محتوا، شبکه‌های اجتماعی، تبلیغات کلیکی، ایمیل مارکتینگ و تحلیل داده، برای ساختن قیف فروش و رشد دادن یک کسب‌وکار آنلاین.',
      en: 'Digital marketing from strategy to execution — content, social media, paid advertising, email marketing and analytics, for building a sales funnel and growing an online business.'
    },
    thumbnail: {
      src: '/courses/thumbnails/digital-marketing.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص Digital Marketing', en: 'Digital Marketing Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 3540,
    price: 4_200_000,
    discountPercent: 20,
    keywords: ['دیجیتال مارکتینگ', 'بازاریابی دیجیتال', 'بازاریابی', 'تبلیغات', 'شبکه های اجتماعی', 'تولید محتوا', 'فروش آنلاین', 'social media', 'advertising', 'content', 'email marketing', 'analytics']
  },
  {
    id: 'scripting-expert',
    categoryId: 'programming',
    title: { fa: 'دوره متخصص اسکریپت نویسی', en: 'Scripting Expert' },
    summary: {
      fa: 'اسکریپت‌نویسی کاربردی با Python، JavaScript، Bash و PowerShell؛ از خودکارسازی کارهای تکراری و مدیریت سیستم تا نوشتن ابزارهای کوچک و امن که در ویندوز و لینوکس واقعاً به کار می‌آیند.',
      en: 'Practical scripting with Python, JavaScript, Bash and PowerShell — from automating repetitive tasks and system administration to writing small, secure tools that are genuinely useful on Windows and Linux.'
    },
    thumbnail: {
      src: '/courses/thumbnails/scripting.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص اسکریپت نویسی', en: 'Scripting Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 3120,
    price: 3_400_000,
    discountPercent: 25,
    keywords: ['اسکریپت نویسی', 'اسکریپت‌نویسی', 'اسکریپت', 'خودکارسازی', 'اتوماسیون', 'بش', 'پاورشل', 'scripting', 'bash', 'powershell', 'automation', 'shell', 'python', 'javascript']
  },
  {
    id: 'kali-linux-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص کالی لینوکس', en: 'Kali Linux Expert' },
    summary: {
      fa: 'کالی لینوکس از نصب و خط فرمان تا تسلط بر ابزارهای اصلی امنیت؛ مدیریت سیستم، شبکه و سرویس‌ها، و کار با ابزارهای شناسایی و ارزیابی امنیتی در محیط آزمایشگاهی و قانونی.',
      en: 'Kali Linux from installation and the command line to command of the main security tools — managing the system, networking and services, and using reconnaissance and assessment tools in a legal lab environment.'
    },
    thumbnail: {
      src: '/courses/thumbnails/kali-linux.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص کالی لینوکس', en: 'Kali Linux Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 4680,
    price: 3_900_000,
    discountPercent: 30,
    keywords: ['کالی لینوکس', 'کالی', 'لینوکس', 'خط فرمان', 'ترمینال', 'امنیت', 'kali', 'linux', 'terminal', 'command line', 'security']
  },
  {
    id: 'black-python-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص پایتون سیاه', en: 'Black Python Expert' },
    summary: {
      fa: 'پایتون برای امنیت و تست نفوذ؛ از برنامه‌نویسی شبکه و سوکت تا ساخت اسکنر، ابزارهای تحلیل ترافیک و خودکارسازی ارزیابی امنیتی، برای کسانی که پایتون می‌دانند و می‌خواهند وارد دنیای امنیت شوند.',
      en: 'Python for security and penetration testing — network and socket programming, building scanners and traffic-analysis tools and automating security assessments, for people who know Python and want to move into security.'
    },
    thumbnail: {
      src: '/courses/thumbnails/black-python.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص پایتون سیاه', en: 'Black Python Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 2390,
    price: 4_600_000,
    discountPercent: 10,
    keywords: ['پایتون سیاه', 'پایتون', 'امنیت', 'تست نفوذ', 'هک', 'شبکه', 'black hat python', 'python', 'security', 'pentest', 'network', 'socket']
  },
  {
    id: 'phishing-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص فیشینگ', en: 'Phishing Expert' },
    summary: {
      fa: 'فیشینگ را از نگاه مهاجم بشناسید تا بتوانید جلوی آن را بگیرید؛ روش‌های مهندسی اجتماعی، تشخیص ایمیل‌ها و صفحه‌های جعلی، اجرای شبیه‌سازی مجاز فیشینگ در سازمان و آموزش و ایمن‌سازی کاربران.',
      en: 'Understand phishing from the attacker\'s side so you can stop it — social-engineering methods, spotting fake emails and pages, running authorised phishing simulations in an organisation and training and protecting its users.'
    },
    thumbnail: {
      src: '/courses/thumbnails/phishing.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص فیشینگ', en: 'Phishing Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 2180,
    price: 3_800_000,
    discountPercent: 20,
    keywords: ['فیشینگ', 'مهندسی اجتماعی', 'ایمیل جعلی', 'صفحه جعلی', 'امنیت', 'phishing', 'social engineering', 'email security', 'awareness', 'security']
  },
  {
    id: 'server-cracking-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص کرک سرور', en: 'Server Cracking Expert' },
    summary: {
      fa: 'امنیت سرور از دید نفوذگر؛ روش‌های رایج حمله به سرویس‌ها و رمزهای عبور، ارزیابی مجاز استحکام احراز هویت، و مقاوم‌سازی لینوکس و ویندوز سرور، فایروال و لاگ‌ها در برابر همین حمله‌ها.',
      en: 'Server security from the intruder\'s point of view — common attacks on services and passwords, authorised assessment of authentication strength, and hardening Linux and Windows servers, firewalls and logging against those same attacks.'
    },
    thumbnail: {
      src: '/courses/thumbnails/server-cracking.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص کرک سرور', en: 'Server Cracking Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 1940,
    price: 5_200_000,
    discountPercent: 15,
    keywords: ['کرک سرور', 'کرک', 'سرور', 'رمز عبور', 'مقاوم سازی', 'فایروال', 'امنیت سرور', 'server', 'password', 'hardening', 'firewall', 'server security', 'brute force']
  },
  {
    id: 'dark-web-operations-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص Dark Web Operations', en: 'Dark Web Operations Expert' },
    summary: {
      fa: 'دارک وب چگونه کار می‌کند؛ شبکهٔ Tor و ناشناسی، امنیت عملیاتی، پایش نشت اطلاعات و تهدیدها و جمع‌آوری اطلاعات تهدید (Threat Intelligence) برای محافظت از افراد و سازمان‌ها.',
      en: 'How the dark web works — the Tor network and anonymity, operational security, monitoring for data leaks and threats and gathering threat intelligence to protect people and organisations.'
    },
    thumbnail: {
      src: '/courses/thumbnails/dark-web-operations.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص Dark Web Operations', en: 'Dark Web Operations Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 1620,
    price: 4_900_000,
    discountPercent: 10,
    keywords: ['دارک وب', 'دیپ وب', 'تور', 'ناشناسی', 'نشت اطلاعات', 'هوش تهدید', 'dark web', 'deep web', 'tor', 'anonymity', 'opsec', 'threat intelligence', 'osint']
  },
  {
    id: 'black-hat-hacking-expert',
    categoryId: 'security',
    title: { fa: 'دوره متخصص Black Hat Hacking', en: 'Black Hat Hacking Expert' },
    summary: {
      fa: 'با ذهنیت و تکنیک‌های نفوذگرها آشنا شوید تا بتوانید در برابرشان دفاع کنید؛ زنجیرهٔ حمله از شناسایی تا دسترسی و ماندگاری، تمرین در آزمایشگاه ایزوله و راه‌های کشف و مهار هر مرحله.',
      en: 'Get to know the mindset and techniques of attackers so you can defend against them — the attack chain from reconnaissance to access and persistence, practised in an isolated lab, with the ways to detect and contain every stage.'
    },
    thumbnail: {
      src: '/courses/thumbnails/black-hat-hacking.webp',
      ...THUMBNAIL_SIZE,
      alt: { fa: 'کاور دوره متخصص Black Hat Hacking', en: 'Black Hat Hacking Expert course cover' }
    },
    instructor: INSTRUCTOR,
    rating: 5,
    students: 3470,
    price: 6_400_000,
    discountPercent: 25,
    keywords: ['بلک هت', 'هک', 'کلاه سیاه', 'هکر', 'نفوذ', 'امنیت', 'black hat', 'hacking', 'hacker', 'red team', 'attack chain', 'security']
  }
];
