/**
 * Lets code outside the courses section (e.g. course search) ask it to reveal
 * a course, without either side knowing about the other's internals.
 */
export const COURSE_SELECT_EVENT = 'portfolio:courseselect';

export interface CourseSelectDetail {
  id: string;
}

export function selectCourse(id: string) {
  document.dispatchEvent(new CustomEvent<CourseSelectDetail>(COURSE_SELECT_EVENT, { detail: { id } }));
}
