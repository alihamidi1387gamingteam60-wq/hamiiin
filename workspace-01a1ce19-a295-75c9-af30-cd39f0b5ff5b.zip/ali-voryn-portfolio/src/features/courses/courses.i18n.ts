import type { Language, Localized } from '@/hooks/use-locale';

/** Interface strings of the courses section. */
export const COURSE_STRINGS = {
  allCategories: { fa: 'همه', en: 'All' },
  categoriesLabel: { fa: 'دسته‌بندی دوره‌ها', en: 'Course categories' },
  carouselLabel: { fa: 'دوره‌ها', en: 'Courses' },
  previous: { fa: 'دورهٔ قبلی', en: 'Previous course' },
  next: { fa: 'دورهٔ بعدی', en: 'Next course' },
  empty: { fa: 'دوره‌های این دسته‌بندی به‌زودی اضافه می‌شوند.', en: 'Courses in this category are coming soon.' },
  instructor: { fa: 'مدرس', en: 'Instructor' },
  students: { fa: 'دانشجو', en: 'students' },
  rating: { fa: 'امتیاز', en: 'Rating' },
  price: { fa: 'قیمت', en: 'Price' },
  listPrice: { fa: 'قیمت اصلی', en: 'List price' },
  currency: { fa: 'تومان', en: 'Toman' },
  free: { fa: 'رایگان', en: 'Free' },
  discount: { fa: 'تخفیف', en: 'off' }
} as const satisfies Record<string, Localized>;

const numberFormats: Localized<Intl.NumberFormat> = {
  fa: new Intl.NumberFormat('fa-IR'),
  en: new Intl.NumberFormat('en-US')
};

export function formatNumber(value: number, language: Language): string {
  return numberFormats[language].format(value);
}

export function formatPercent(value: number, language: Language): string {
  return language === 'fa' ? `${formatNumber(value, language)}٪` : `${formatNumber(value, language)}%`;
}

/** "Slide 2 of 4" style labels for the carousel, in the active language. */
export function slidePosition(position: number, total: number, language: Language): string {
  const [current, count] = [formatNumber(position, language), formatNumber(total, language)];
  return language === 'fa' ? `دورهٔ ${current} از ${count}` : `Course ${current} of ${count}`;
}

/** Final price in Toman after the discount, rounded to the nearest 1,000. */
export function discountedPrice(price: number, discountPercent: number): number {
  const percent = Math.min(100, Math.max(0, discountPercent));
  return Math.round((price * (100 - percent)) / 100 / 1000) * 1000;
}
