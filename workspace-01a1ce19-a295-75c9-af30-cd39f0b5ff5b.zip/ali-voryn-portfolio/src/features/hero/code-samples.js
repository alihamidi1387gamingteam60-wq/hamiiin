/**
 * The snippets typed in the code window of the opening header.
 *
 * They are read in two places: code-window.js types them, and HeroSection.tsx
 * renders each one invisibly inside the window so the window always has the
 * height of its longest snippet — typing never changes the height of the header.
 */
export const CODE_SAMPLES = [
  `export async function verifyBlock(
  chainId: number,
  hash: Hex
): Promise<boolean> {
  const block = await client.getBlock({ hash });
  return isFinalized(block, chainId);
}` ,
  `const response = await fetch('/v1/blocks');
if (!response.ok) {
  throw new Error('Request failed');
}
const blocks = await response.json();
return blocks.filter(isVerified);`,
  `export function commit(state: State) {
  const next = applyRules(state);
  const digest = hash(next);
  return ledger.append({ digest, next });
}`
];
