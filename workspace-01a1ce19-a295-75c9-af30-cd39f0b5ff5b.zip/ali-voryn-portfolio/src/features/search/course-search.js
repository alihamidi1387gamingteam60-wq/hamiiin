import { selectCourse } from '@/features/courses/course-events';
import { COURSES } from '@/features/courses/courses.data';

/** Lower-cases and unifies Persian/Arabic letter variants and half-spaces so queries match however they are typed. */
function normalize(value) {
  return value
    .toLowerCase()
    .replace(/[\u064A\u0649]/g, '\u06CC') // Arabic yeh, alef maksura -> Persian yeh
    .replace(/\u0643/g, '\u06A9') // Arabic kaf -> Persian kaf
    .replace(/[\u200C\u200F\u200E]/g, ' ') // half-space and direction marks -> space
    .replace(/\s+/g, ' ')
    .trim();
}

/** Searchable text of every course, in both languages, built once from the catalogue. */
const COURSE_INDEX = COURSES.map(course => ({
  id: course.id,
  title: course.title,
  text: normalize([course.title.fa, course.title.en, course.summary.fa, course.summary.en, ...course.keywords].join(' '))
}));

export function initCourseSearch() {
  const trigger = document.getElementById('openCourseSearch');
  const dialog = document.getElementById('courseSearchDialog');
  const backdrop = document.getElementById('courseSearchBackdrop');
  const closeButton = document.getElementById('closeCourseSearch');
  const input = document.getElementById('courseSearchInput');
  const results = document.getElementById('courseSearchResults');
  const root = document.documentElement;
  if (!trigger || !dialog || !backdrop || !closeButton || !input || !results) return;

  let previousFocus = null;
  let english = root.lang === 'en';

  function setStatus(message) {
    results.replaceChildren();
    const status = document.createElement('p');
    status.className = 'course-search-empty';
    status.id = 'courseSearchStatus';
    status.textContent = message;
    results.append(status);
    dialog.setAttribute('aria-describedby', status.id);
  }

  function search(query = '') {
    const normalized = normalize(query);

    if (!COURSE_INDEX.length) {
      setStatus(english ? 'No course titles have been added for search yet.' : 'عنوان دوره‌ای برای جستجو ثبت نشده است.');
      return;
    }
    if (!normalized) {
      setStatus(english ? 'Type a course name or keyword to search.' : 'نام یا کلیدواژهٔ دوره را برای جستجو بنویسید.');
      return;
    }

    // Courses whose title matches come first.
    const inTitle = course => normalize(`${course.title.fa} ${course.title.en}`).includes(normalized);
    const matches = COURSE_INDEX
      .filter(course => course.text.includes(normalized))
      .sort((a, b) => Number(inTitle(b)) - Number(inTitle(a)));
    if (!matches.length) {
      setStatus(english ? 'No matching courses found.' : 'دوره‌ای با این عبارت پیدا نشد.');
      return;
    }

    results.replaceChildren();
    dialog.setAttribute('aria-describedby', 'courseSearchResults');
    for (const course of matches) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'course-search-result';
      button.setAttribute('role', 'listitem');
      button.textContent = course.title[english ? 'en' : 'fa'];
      button.addEventListener('click', () => {
        close();
        selectCourse(course.id); // the courses section slides to the card and highlights it
      });
      results.append(button);
    }
  }

  function updateLanguage() {
    english = root.lang === 'en';
    input.placeholder = english ? 'Type a course name…' : 'نام دوره را بنویسید…';
    input.setAttribute('aria-label', english ? 'Search course titles' : 'جستجوی نام دوره‌ها');
    closeButton.setAttribute('aria-label', english ? 'Close search' : 'بستن جستجو');
    search(input.value);
  }

  function open() {
    previousFocus = document.activeElement;
    dialog.hidden = false;
    backdrop.hidden = false;
    input.value = '';
    updateLanguage();
    window.requestAnimationFrame(() => input.focus());
  }
  function close() {
    dialog.hidden = true;
    backdrop.hidden = true;
    if (previousFocus instanceof HTMLElement) previousFocus.focus();
  }

  trigger.addEventListener('click', open);
  closeButton.addEventListener('click', close);
  backdrop.addEventListener('click', close);
  input.addEventListener('input', () => search(input.value));
  document.addEventListener('portfolio:languagechange', updateLanguage);
  document.addEventListener('keydown', event => {
    if (dialog.hidden) return;
    if (event.key === 'Escape') { close(); return; }
    if (event.key === 'Tab') {
      const focusable = [...dialog.querySelectorAll('button:not([disabled]), input:not([disabled])')];
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  updateLanguage();
}
