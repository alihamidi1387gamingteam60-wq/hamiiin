import type { Localized } from '@/hooks/use-locale';

/** A section of a page that navigation can point at. */
export type PageSection = {
  /** `id` of the section element. */
  id: string;
  /** Short name, for menus and the dots navigation. */
  label: Localized;
  /** Heading of the section: `lead` is the coloured first word, `rest` what follows it. */
  title?: { lead: Localized; rest?: Localized };
};

/** Sections of the home page, top to bottom. The first one is the opening header. */
export const HOME_SECTIONS: readonly PageSection[] = [
  { id: 'home', label: { fa: 'خانه', en: 'Home' } },
  {
    id: 'about',
    label: { fa: 'درباره من', en: 'About' },
    title: { lead: { fa: 'درباره', en: 'About' }, rest: { fa: 'من', en: 'Me' } }
  },
  {
    id: 'courses',
    label: { fa: 'دوره‌ها', en: 'Courses' },
    title: { lead: { fa: 'محبوب‌ترین', en: 'Popular' }, rest: { fa: 'دوره‌ها', en: 'Courses' } }
  },
  {
    id: 'categories',
    label: { fa: 'دسته‌بندی‌ها', en: 'Categories' },
    title: { lead: { fa: 'دسته‌بندی', en: 'Course' }, rest: { fa: 'دوره‌ها', en: 'Categories' } }
  },
  {
    id: 'experience',
    label: { fa: 'سابقه', en: 'Experience' },
    title: { lead: { fa: 'سابقه', en: 'Experience' } }
  },
  {
    id: 'contact',
    label: { fa: 'راه ارتباطی', en: 'Contact' },
    title: { lead: { fa: 'راه', en: 'Contact' }, rest: { fa: 'ارتباطی', en: 'Me' } }
  }
];

/** Heading of a home-page section, by section id. */
export function sectionTitle(id: string): NonNullable<PageSection['title']> {
  const title = HOME_SECTIONS.find(section => section.id === id)?.title;
  if (!title) throw new Error(`Section "${id}" has no title`);
  return title;
}
