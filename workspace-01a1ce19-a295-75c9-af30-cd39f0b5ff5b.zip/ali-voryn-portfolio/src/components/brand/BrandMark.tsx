import './brand.css';

type BrandMarkProps = {
  /** Rendered width and height in px. */
  size?: number;
  className?: string;
};

/**
 * The "AV" monogram of Ali Voryn: one continuous line that draws the A and runs
 * straight on into the V, with a short floating bar that completes the A.
 * It takes its colour from the theme accent, so it follows the chosen palette.
 */
export function BrandMark({ size = 22, className }: BrandMarkProps) {
  return (
    <svg
      className={className ? `brand-mark ${className}` : 'brand-mark'}
      viewBox="0 0 24 24"
      width={size}
      height={size}
      aria-hidden="true"
      focusable="false"
    >
      <path className="brand-mark__line" pathLength={1} d="M3.5 18.5 9.25 5.5 15 18.5 20.5 5.5" />
      <path className="brand-mark__spark" pathLength={1} d="M3.5 18.5 9.25 5.5 15 18.5 20.5 5.5" />
      <path className="brand-mark__bar" d="M7.1 14.2h4.3" />
    </svg>
  );
}
