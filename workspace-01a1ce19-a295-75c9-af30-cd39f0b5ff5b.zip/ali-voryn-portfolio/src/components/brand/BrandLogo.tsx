import { BrandMark } from './BrandMark';
import './brand.css';

type BrandLogoProps = {
  /** Where the logo links to. */
  href?: string;
  /** Show the animated signature next to the icon. */
  showSignature?: boolean;
  className?: string;
};

/**
 * Site logo: the monogram in a tile shaped like the other header buttons, plus
 * the name as a signature that writes itself — a 3-second looping GIF
 * (public/brand/ali-voryn-signature.gif; a still picture for reduced motion).
 * It sits at the start of its container, so it is on the right in Persian and on
 * the left in English without any extra rule.
 */
export function BrandLogo({ href = '#home', showSignature = true, className }: BrandLogoProps) {
  return (
    <a className={className ? `brand ${className}` : 'brand'} href={href} aria-label="Ali Voryn">
      <span className="brand__tile">
        <BrandMark />
      </span>
      {showSignature ? <span className="brand__signature" aria-hidden="true" /> : null}
    </a>
  );
}
