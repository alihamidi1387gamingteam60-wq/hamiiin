'use client';

import { useEffect, useRef } from 'react';
import type { KeyboardEvent } from 'react';
import './filter-tabs.css';

export interface FilterTab {
  id: string;
  label: string;
}

export interface FilterTabsProps {
  tabs: readonly FilterTab[];
  /** Id of the selected tab. */
  value: string;
  onChange: (id: string) => void;
  /** Accessible name of the tab list. */
  ariaLabel: string;
  /** Prefix for element ids; tab ids are `${idPrefix}-tab-${tab.id}`. */
  idPrefix: string;
  /** Id of the panel the tabs control. */
  panelId: string;
  className?: string;
}

export const filterTabId = (idPrefix: string, tabId: string) => `${idPrefix}-tab-${tabId}`;

/**
 * Pill-shaped single-select filter with a highlight that glides to the selected
 * pill. Implements the WAI-ARIA tabs pattern (arrow keys, Home/End) and scrolls
 * horizontally when the pills do not fit.
 */
export function FilterTabs({ tabs, value, onChange, ariaLabel, idPrefix, panelId, className }: FilterTabsProps) {
  const listRef = useRef<HTMLDivElement>(null);

  // Position the highlight under the selected pill; keep it right through resizes,
  // font loading and label changes (e.g. a language switch).
  useEffect(() => {
    const list = listRef.current;
    if (!list) return;
    const place = () => {
      const selected = list.querySelector<HTMLElement>('[aria-selected="true"]');
      if (!selected) return;
      list.style.setProperty('--filter-tabs-x', `${selected.offsetLeft}px`);
      list.style.setProperty('--filter-tabs-width', `${selected.offsetWidth}px`);
      if (list.dataset.ready !== 'true') {
        void list.offsetWidth; // commit the first position before transitions are switched on
        list.dataset.ready = 'true';
      }
    };
    place();
    const observer = new ResizeObserver(place);
    observer.observe(list);
    for (const tab of list.querySelectorAll('[role="tab"]')) observer.observe(tab);
    return () => observer.disconnect();
  }, [tabs, value]);

  // Bring the selected pill into view when the list is scrolled sideways.
  useEffect(() => {
    const list = listRef.current;
    const selected = list?.querySelector<HTMLElement>('[aria-selected="true"]');
    if (!list || !selected || list.scrollWidth <= list.clientWidth) return;
    const target = selected.offsetLeft - (list.clientWidth - selected.offsetWidth) / 2;
    list.scrollTo({ left: target, behavior: 'smooth' });
  }, [value]);

  function onKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    const list = listRef.current;
    if (!list) return;
    const current = tabs.findIndex(tab => tab.id === value);
    const forwardKey = getComputedStyle(list).direction === 'rtl' ? 'ArrowLeft' : 'ArrowRight';
    const backwardKey = forwardKey === 'ArrowLeft' ? 'ArrowRight' : 'ArrowLeft';
    let nextIndex: number;
    if (event.key === forwardKey) nextIndex = (current + 1) % tabs.length;
    else if (event.key === backwardKey) nextIndex = (current - 1 + tabs.length) % tabs.length;
    else if (event.key === 'Home') nextIndex = 0;
    else if (event.key === 'End') nextIndex = tabs.length - 1;
    else return;
    event.preventDefault();
    const nextTab = tabs[nextIndex];
    onChange(nextTab.id);
    list.querySelector<HTMLElement>(`#${CSS.escape(filterTabId(idPrefix, nextTab.id))}`)?.focus();
  }

  return (
    <div
      className={['filter-tabs', className].filter(Boolean).join(' ')}
      role="tablist"
      aria-label={ariaLabel}
      ref={listRef}
      onKeyDown={onKeyDown}
    >
      <span className="filter-tabs__highlight" aria-hidden="true" />
      {tabs.map(tab => {
        const selected = tab.id === value;
        return (
          <button
            className="filter-tabs__tab"
            type="button"
            role="tab"
            id={filterTabId(idPrefix, tab.id)}
            aria-selected={selected}
            aria-controls={panelId}
            tabIndex={selected ? 0 : -1}
            onClick={() => onChange(tab.id)}
            key={tab.id}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}
