const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';
/** Elements are shown while they touch this band of the window (10% is cut off at the top and at the bottom). */
const BAND = '-10% 0px -10% 0px';
/** How far an element travels sideways, in px. */
const DISTANCE = 56;
/** Soft focus of the hidden state, in px — only on larger screens: phones repaint a blurred layer every frame. */
const BLUR = 5;
const BLUR_QUERY = '(min-width: 681px)';
/** Delay between two elements that arrive together, in ms, and how many steps it may add up to. */
const STAGGER = 90;
const LEAVE_STAGGER = 35;
const MAX_STEPS = 7;
const ENTER = { duration: 780, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' };
const LEAVE = { duration: 380, easing: 'cubic-bezier(0.4, 0, 1, 1)' };

const started = new WeakSet();
const running = new WeakMap();
let observer = null;
let reducedMotion = null;
let blurAllowed = null;

/** Sideways offset of the hidden state: `start` is the side the text starts on (right in Persian). */
function offsetOf(element) {
  const side = element.dataset.reveal || element.dataset.revealItem;
  if (side !== 'start' && side !== 'end') return 0;
  const rtl = document.documentElement.dir === 'rtl';
  return (side === 'start') === rtl ? DISTANCE : -DISTANCE;
}

/** The hidden state of an element as a keyframe. */
function hiddenFrame(element) {
  const offset = offsetOf(element);
  const frame = { opacity: 0, translate: `${offset}px 0` };
  // Only what travels is blurred; a plain fade (often a large wrapper) stays a cheap opacity change.
  if (offset !== 0 && blurAllowed.matches) frame.filter = `blur(${BLUR}px)`;
  return frame;
}

/**
 * Where a movement starts (read phase): the hidden state when the element
 * comes in from rest, otherwise where it is right now — its own look when it
 * leaves, or the point an interrupted movement had reached.
 */
function startFrame(element, show) {
  if (show && !running.has(element)) return hiddenFrame(element);
  const style = getComputedStyle(element);
  const frame = { opacity: style.opacity, translate: style.translate };
  if (offsetOf(element) !== 0 && blurAllowed.matches) frame.filter = style.filter;
  return frame;
}

/**
 * Plays one element in or out (write phase) with the Web Animations API, so the
 * element's own CSS transitions and transforms stay untouched (it animates
 * `translate`, not `transform`).
 */
function play(element, show, from, delay) {
  running.get(element)?.cancel();
  // Showing: from the start frame to whatever the element's own styles are.
  const frames = show ? [{ offset: 0, ...from }] : [from, hiddenFrame(element)];
  const animation = element.animate(frames, { ...(show ? ENTER : LEAVE), delay, fill: 'backwards' });
  running.set(element, animation);
  const forget = () => {
    if (running.get(element) === animation) running.delete(element);
  };
  animation.addEventListener('finish', forget);
  animation.addEventListener('cancel', forget);
}

/** The elements a trigger moves: itself and, for a group, its items. */
function targetsOf(trigger) {
  const targets = trigger.hasAttribute('data-reveal') ? [trigger] : [];
  if (!trigger.hasAttribute('data-reveal-group')) return targets;
  const width = document.documentElement.clientWidth;
  for (const item of trigger.querySelectorAll('[data-reveal-item]')) {
    // Items outside the window sideways (slides waiting in a carousel) are not moved: they just follow the group's state.
    const box = item.getBoundingClientRect();
    if (box.right > 0 && box.left < width) targets.push(item);
  }
  return targets;
}

function onIntersect(entries) {
  const changes = { true: [], false: [] };
  for (const entry of entries) {
    const trigger = entry.target;
    const show = entry.isIntersecting;
    if (show === (trigger.dataset.revealState === 'in')) continue;
    changes[show].push(trigger);
  }

  for (const show of [false, true]) {
    const triggers = changes[show];
    if (triggers.length === 0) continue;
    triggers.sort((a, b) => (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1));

    // Read phase: every target and its start frame. Nothing is written until all reads are done (no layout thrashing).
    let step = 0;
    const moves = [];
    for (const trigger of triggers) {
      if (reducedMotion.matches) break;
      const own = Number(trigger.dataset.revealDelay) || 0;
      for (const element of targetsOf(trigger)) {
        const delay = own + Math.min(step, MAX_STEPS) * (show ? STAGGER : LEAVE_STAGGER);
        moves.push([element, startFrame(element, show), delay]);
        step += 1;
      }
    }

    // Write phase.
    for (const [element, from, delay] of moves) play(element, show, from, delay);
    for (const trigger of triggers) {
      if (show) trigger.dataset.revealState = 'in';
      else delete trigger.dataset.revealState;
    }
  }
}

/**
 * Scroll reveal for every `[data-reveal]` element and `[data-reveal-group]`
 * under `root` (see components/ui/reveal/reveal.css for the attributes):
 * hidden at first, they come in from the side when they are scrolled into the
 * reading band — elements arriving together one after another — leave when
 * they are scrolled out of it and come in again on the way back.
 *
 * One shared IntersectionObserver, no scroll listener. Safe to call again
 * after new elements were added. With reduced motion everything simply shows.
 *
 * @param {ParentNode} [root]
 */
export function initScrollReveal(root = document) {
  reducedMotion ??= window.matchMedia(REDUCED_MOTION_QUERY);
  blurAllowed ??= window.matchMedia(BLUR_QUERY);
  observer ??= new IntersectionObserver(onIntersect, { rootMargin: BAND });
  for (const trigger of root.querySelectorAll('[data-reveal], [data-reveal-group]')) {
    if (started.has(trigger)) continue;
    started.add(trigger);
    observer.observe(trigger);
  }
}
