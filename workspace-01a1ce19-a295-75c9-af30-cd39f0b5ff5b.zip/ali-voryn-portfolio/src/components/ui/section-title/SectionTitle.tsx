import type { Localized } from '@/hooks/use-locale';
import './section-title.css';

export type SectionTitleText = {
  /** First word(s): set in the theme colour, with the travelling underline. */
  lead: Localized;
  /** The rest of the title, in the text colour. Omit for a one-word title. */
  rest?: Localized;
};

export type SectionTitleProps = SectionTitleText & {
  /** Heading level. */
  as?: 'h1' | 'h2' | 'h3';
  /** Scroll-reveal direction (see ui/reveal); omit for a title that is always visible. */
  reveal?: 'start' | 'end' | 'fade';
  className?: string;
};

/**
 * Title of a section: the first word takes the colour of the active theme and
 * a line shoots under it from its first letter to its last, leaves, and comes
 * back every three seconds. Both languages are in the markup; the language
 * switch swaps them (`data-fa` / `data-en`).
 *
 *   --section-title-accent   colour of the first word and its line (default var(--accent))
 *   --section-title-period   length of one cycle (default 3s)
 */
export function SectionTitle({ lead, rest, as: Heading = 'h2', reveal, className }: SectionTitleProps) {
  return (
    <Heading className={className ? `section-title ${className}` : 'section-title'} data-reveal={reveal}>
      <span className="section-title__lead">
        <span data-fa={lead.fa} data-en={lead.en}>{lead.fa}</span>
        <i className="section-title__trail" aria-hidden="true" />
      </span>
      {rest ? <>{' '}<span className="section-title__rest" data-fa={rest.fa} data-en={rest.en}>{rest.fa}</span></> : null}
    </Heading>
  );
}
