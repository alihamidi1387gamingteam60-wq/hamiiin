'use client';

import { useImperativeHandle } from 'react';
import type { ReactNode, Ref } from 'react';
import { useCarousel } from './useCarousel';
import type { CarouselDirection } from './useCarousel';
import './carousel.css';

export interface CarouselHandle {
  next(): void;
  previous(): void;
  /** Slides to the item at `index` (0-based). */
  goTo(index: number): void;
}

export interface CarouselLabels {
  previous: string;
  next: string;
  /** Accessible name of a slide and of its pagination dot, e.g. "Course 2 of 4". */
  position: (position: number, total: number) => string;
}

export interface CarouselProps<T> {
  items: readonly T[];
  getKey: (item: T) => string;
  /** `isClone` is true for the extra copies that make the loop seamless. */
  renderItem: (item: T, state: { index: number; isClone: boolean }) => ReactNode;
  /** Accessible name of the whole carousel. */
  ariaLabel: string;
  labels: CarouselLabels;
  direction?: CarouselDirection;
  /** Wrap around endlessly (default). Has no effect while every item fits on screen. */
  loop?: boolean;
  /** Milliseconds between automatic advances; `0` turns autoplay off. */
  autoplayInterval?: number;
  showArrows?: boolean;
  showPagination?: boolean;
  className?: string;
  ref?: Ref<CarouselHandle>;
}

/**
 * Generic, content-agnostic carousel: endless loop, autoplay (paused on hover,
 * keyboard focus, off-screen and for reduced motion), drag/swipe, arrow keys,
 * arrows and pagination dots. Slide size and spacing come from CSS:
 *
 *   --carousel-slide-width   width of one slide (default 320px)
 *   --carousel-gap           space between slides (default 20px)
 *
 * When all items fit in the available width it renders them as a plain row.
 */
export function Carousel<T>({
  items,
  getKey,
  renderItem,
  ariaLabel,
  labels,
  direction = 'ltr',
  loop = true,
  autoplayInterval = 4000,
  showArrows = true,
  showPagination = true,
  className,
  ref
}: CarouselProps<T>) {
  const count = items.length;
  const {
    viewportRef, trackRef, rootProps, viewportProps,
    cloneCount, scrollable, activeIndex, next, previous, goTo
  } = useCarousel({ count, direction, loop, autoplayInterval });

  useImperativeHandle(ref, () => ({ next, previous, goTo }), [next, previous, goTo]);

  const clones = Array.from({ length: cloneCount }, (_, offset) => items[offset % count]);
  const showControls = scrollable && (showArrows || showPagination);

  return (
    <section
      className={['carousel', className].filter(Boolean).join(' ')}
      aria-roledescription="carousel"
      aria-label={ariaLabel}
      data-direction={direction}
      data-scrollable={scrollable}
      {...rootProps}
    >
      <div className="carousel__viewport" ref={viewportRef} {...viewportProps}>
        <div className="carousel__track" ref={trackRef}>
          {items.map((item, index) => (
            <div
              className="carousel__slide"
              role="group"
              aria-roledescription="slide"
              aria-label={labels.position(index + 1, count)}
              data-active={scrollable && index === activeIndex}
              key={getKey(item)}
            >
              {renderItem(item, { index, isClone: false })}
            </div>
          ))}
          {clones.map((item, offset) => (
            <div className="carousel__slide" aria-hidden="true" key={`clone-${offset}`}>
              {renderItem(item, { index: offset % count, isClone: true })}
            </div>
          ))}
        </div>
      </div>

      {showControls && (
        <div className="carousel__controls">
          {showArrows && (
            <button className="carousel__arrow" type="button" aria-label={labels.previous} onClick={previous}>
              <svg className="carousel__arrow-icon carousel__arrow-icon--previous" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7" /></svg>
            </button>
          )}
          {showPagination && (
            <div className="carousel__pagination">
              {items.map((item, index) => (
                <button
                  className="carousel__dot"
                  type="button"
                  aria-label={labels.position(index + 1, count)}
                  aria-current={index === activeIndex ? 'true' : undefined}
                  onClick={() => goTo(index)}
                  key={getKey(item)}
                />
              ))}
            </div>
          )}
          {showArrows && (
            <button className="carousel__arrow" type="button" aria-label={labels.next} onClick={next}>
              <svg className="carousel__arrow-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7" /></svg>
            </button>
          )}
        </div>
      )}
    </section>
  );
}
