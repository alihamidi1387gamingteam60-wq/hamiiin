'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import type { FocusEvent, KeyboardEvent, MouseEvent, PointerEvent } from 'react';

export type CarouselDirection = 'ltr' | 'rtl';

export interface UseCarouselOptions {
  /** Number of real slides. */
  count: number;
  direction: CarouselDirection;
  /** Wrap around endlessly when the slides do not fit in the viewport. */
  loop: boolean;
  /** Milliseconds between automatic advances; `0` disables autoplay. */
  autoplayInterval: number;
}

interface Layout {
  /** Extra copies of the first slides rendered after the real ones (loop mode only). */
  cloneCount: number;
  /** False when every slide fits in the viewport, so there is nothing to slide. */
  scrollable: boolean;
}

const EASING_MS = 150; // time constant of the slide animation
const DRAG_THRESHOLD_PX = 6; // movement before a press becomes a drag (keeps clicks working)
const FLICK_PROJECTION_MS = 220; // how far a release velocity carries the slider
const MAX_FLICK_SLIDES = 3;
const REST_EPSILON = 0.0015;

/**
 * Headless carousel engine: position, endless loop, autoplay, drag/swipe and
 * keyboard control. It only needs refs to a viewport and a track element whose
 * children are equally sized slides, so it can drive any markup.
 *
 * The position is a float measured in slides. In loop mode it always stays in
 * `[0, count)`: because copies of the first slides follow the last one, a
 * position `p` looks identical to `p + count`, so wrapping is invisible.
 */
export function useCarousel({ count, direction, loop, autoplayInterval }: UseCarouselOptions) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  const [layout, setLayout] = useState<Layout>({ cloneCount: 0, scrollable: false });
  const [activeIndex, setActiveIndex] = useState(0);

  // Mutable engine state lives in a ref so animation frames never re-render React.
  const engine = useRef({
    position: 0,
    target: 0,
    step: 0, // slide width + gap, in px
    maxPosition: 0, // last reachable position when not looping
    looping: false,
    scrollable: false,
    frame: 0,
    lastFrameTime: 0,
    autoplayTimer: 0,
    reducedMotion: false,
    // pause sources
    hovered: false,
    focused: false,
    onScreen: true,
    // drag
    pointerId: -1,
    dragging: false,
    pressX: 0,
    lastX: 0,
    lastMoveTime: 0,
    dragDelta: 0,
    velocity: 0, // slides per ms
    suppressClick: false
  });

  const sign = direction === 'rtl' ? 1 : -1;
  const signRef = useRef(sign);
  const countRef = useRef(count);
  const autoplayRef = useRef(autoplayInterval);

  const paint = useCallback(() => {
    const state = engine.current;
    const track = trackRef.current;
    if (track) track.style.transform = `translate3d(${signRef.current * state.position * state.step}px,0,0)`;
  }, []);

  /** Keeps the position inside the valid range (wrap when looping, clamp otherwise). */
  const constrain = useCallback(() => {
    const state = engine.current;
    const total = countRef.current;
    if (state.looping && total > 0) {
      const turns = Math.floor(state.position / total);
      if (turns !== 0) {
        state.position -= turns * total;
        state.target -= turns * total;
      }
    } else {
      state.position = Math.min(state.maxPosition, Math.max(0, state.position));
      state.target = Math.min(state.maxPosition, Math.max(0, state.target));
    }
  }, []);

  const syncActiveIndex = useCallback(() => {
    const total = countRef.current;
    if (total > 0) setActiveIndex(((Math.round(engine.current.target) % total) + total) % total);
  }, []);

  const animate = useCallback(() => {
    const state = engine.current;
    if (state.frame) return;
    state.lastFrameTime = performance.now();
    const tick = (now: number) => {
      const elapsed = Math.min(64, now - state.lastFrameTime);
      state.lastFrameTime = now;
      const distance = state.target - state.position;
      if (state.reducedMotion || Math.abs(distance) < REST_EPSILON) {
        state.position = state.target;
        state.frame = 0;
      } else {
        state.position += distance * (1 - Math.exp(-elapsed / EASING_MS));
        state.frame = requestAnimationFrame(tick);
      }
      constrain();
      paint();
    };
    state.frame = requestAnimationFrame(tick);
  }, [constrain, paint]);

  const stopAutoplay = useCallback(() => {
    window.clearInterval(engine.current.autoplayTimer);
    engine.current.autoplayTimer = 0;
  }, []);

  /** (Re)starts the autoplay timer, or leaves it stopped while autoplay is off or paused. */
  const startAutoplay = useCallback(() => {
    const state = engine.current;
    stopAutoplay();
    const interval = autoplayRef.current;
    const paused = state.hovered || state.focused || state.dragging || !state.onScreen || document.hidden;
    if (!interval || !state.scrollable || state.reducedMotion || paused) return;
    state.autoplayTimer = window.setInterval(() => {
      const atEnd = !state.looping && state.target >= state.maxPosition - REST_EPSILON;
      state.target = atEnd ? 0 : Math.round(state.target) + 1;
      constrain();
      syncActiveIndex();
      animate();
    }, interval);
  }, [animate, constrain, stopAutoplay, syncActiveIndex]);

  const moveTo = useCallback((target: number) => {
    const state = engine.current;
    if (!state.scrollable) return;
    state.target = target;
    constrain();
    syncActiveIndex();
    animate();
    startAutoplay();
  }, [animate, constrain, startAutoplay, syncActiveIndex]);

  const next = useCallback(() => moveTo(Math.round(engine.current.target) + 1), [moveTo]);
  const previous = useCallback(() => moveTo(Math.round(engine.current.target) - 1), [moveTo]);

  /** Slides to a real slide by index, taking the shortest way round when looping. */
  const goTo = useCallback((index: number) => {
    const state = engine.current;
    const total = countRef.current;
    if (!total) return;
    let target = Math.min(total - 1, Math.max(0, Math.round(index)));
    if (state.looping) {
      const current = state.position;
      target = [target - total, target, target + total].reduce((best, candidate) =>
        Math.abs(candidate - current) < Math.abs(best - current) ? candidate : best);
    }
    moveTo(target);
  }, [moveTo]);

  // Keep the latest option values available to long-lived callbacks.
  useEffect(() => {
    signRef.current = sign;
    countRef.current = count;
    autoplayRef.current = autoplayInterval;
    const state = engine.current;
    if (state.target > Math.max(0, count - 1) && !state.looping) state.target = state.position = 0;
    paint();
    startAutoplay();
  }, [autoplayInterval, count, paint, sign, startAutoplay]);

  // Measure slides, decide between static / sliding / looping, and react to resizes.
  useEffect(() => {
    const viewport = viewportRef.current;
    const track = trackRef.current;
    if (!viewport || !track) return;
    const state = engine.current;

    const measure = () => {
      const slide = track.firstElementChild as HTMLElement | null;
      const total = countRef.current;
      if (!slide || !total) return;
      const gap = parseFloat(getComputedStyle(track).columnGap) || 0;
      const step = slide.offsetWidth + gap;
      // The viewport may have padding (room for slide shadows); slides align to its content box.
      const style = getComputedStyle(viewport);
      const visibleWidth = viewport.clientWidth;
      const viewportWidth = visibleWidth - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
      if (!step || viewportWidth <= 0) return;
      const contentWidth = total * step - gap;
      const scrollable = total > 1 && contentWidth > viewportWidth + 1;
      const looping = scrollable && loop;

      state.step = step;
      state.scrollable = scrollable;
      state.looping = looping;
      state.maxPosition = scrollable ? Math.max(0, (contentWidth - viewportWidth) / step) : 0;
      if (!scrollable) state.position = state.target = 0;
      constrain();
      paint();

      const cloneCount = looping ? Math.ceil(visibleWidth / step) + 1 : 0;
      setLayout(previousLayout =>
        previousLayout.cloneCount === cloneCount && previousLayout.scrollable === scrollable
          ? previousLayout
          : { cloneCount, scrollable });
      startAutoplay();
    };

    // Measure right away so the carousel can be driven (e.g. `goTo`) as soon as it has mounted,
    // and resume a slide that a previous run of this effect interrupted in its cleanup.
    measure();
    if (Math.abs(state.target - state.position) > REST_EPSILON) animate();
    const resizeObserver = new ResizeObserver(measure);
    resizeObserver.observe(viewport);
    if (track.firstElementChild) resizeObserver.observe(track.firstElementChild);

    const visibilityObserver = new IntersectionObserver(entries => {
      state.onScreen = entries[0]?.isIntersecting ?? true;
      startAutoplay();
    }, { threshold: 0.2 });
    visibilityObserver.observe(viewport);

    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onMotionChange = () => { state.reducedMotion = motionQuery.matches; startAutoplay(); };
    onMotionChange();
    motionQuery.addEventListener('change', onMotionChange);
    document.addEventListener('visibilitychange', startAutoplay);

    // Focusing an off-screen slide makes the browser scroll the clipped viewport; undo that.
    const resetScroll = () => { if (viewport.scrollLeft !== 0) viewport.scrollLeft = 0; };
    viewport.addEventListener('scroll', resetScroll, { passive: true });

    return () => {
      resizeObserver.disconnect();
      visibilityObserver.disconnect();
      motionQuery.removeEventListener('change', onMotionChange);
      document.removeEventListener('visibilitychange', startAutoplay);
      viewport.removeEventListener('scroll', resetScroll);
      stopAutoplay();
      cancelAnimationFrame(state.frame);
      state.frame = 0;
    };
  }, [animate, constrain, count, loop, paint, startAutoplay, stopAutoplay]);

  /* ---------------------------------------------------------------- drag -- */

  const onPointerDown = useCallback((event: PointerEvent<HTMLDivElement>) => {
    const state = engine.current;
    if (!state.scrollable || state.pointerId !== -1) return;
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    state.pointerId = event.pointerId;
    state.pressX = state.lastX = event.clientX;
    state.lastMoveTime = event.timeStamp;
    state.dragDelta = 0;
    state.velocity = 0;
  }, []);

  const onPointerMove = useCallback((event: PointerEvent<HTMLDivElement>) => {
    const state = engine.current;
    if (event.pointerId !== state.pointerId) return;
    if (!state.dragging) {
      if (Math.abs(event.clientX - state.pressX) < DRAG_THRESHOLD_PX) return;
      state.dragging = true;
      state.lastX = event.clientX;
      state.lastMoveTime = event.timeStamp;
      cancelAnimationFrame(state.frame);
      state.frame = 0;
      stopAutoplay();
      event.currentTarget.setPointerCapture(event.pointerId);
      event.currentTarget.dataset.dragging = 'true';
    }
    const moved = (event.clientX - state.lastX) / (signRef.current * state.step);
    const elapsed = Math.max(1, event.timeStamp - state.lastMoveTime);
    state.velocity = state.velocity * 0.6 + (moved / elapsed) * 0.4;
    state.lastX = event.clientX;
    state.lastMoveTime = event.timeStamp;
    state.dragDelta += moved;
    state.position += moved;
    state.target = state.position;
    constrain();
    paint();
  }, [constrain, paint, stopAutoplay]);

  const endDrag = useCallback((event: PointerEvent<HTMLDivElement>) => {
    const state = engine.current;
    if (event.pointerId !== state.pointerId) return;
    state.pointerId = -1;
    if (!state.dragging) return;
    state.dragging = false;
    delete event.currentTarget.dataset.dragging;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);

    // Settle on a whole slide: follow the release velocity, and always move at
    // least one slide once the drag was clearly intentional.
    const origin = state.position - state.dragDelta;
    const stale = event.timeStamp - state.lastMoveTime > 90;
    let target = Math.round(state.position + (stale ? 0 : state.velocity * FLICK_PROJECTION_MS));
    if (Math.abs(state.dragDelta) > 0.12 && target === Math.round(origin)) target += Math.sign(state.dragDelta);
    target = Math.min(Math.round(origin) + MAX_FLICK_SLIDES, Math.max(Math.round(origin) - MAX_FLICK_SLIDES, target));

    // The click that follows a drag must not activate links or buttons inside a slide.
    state.suppressClick = true;
    window.setTimeout(() => { state.suppressClick = false; }, 0);
    moveTo(target);
  }, [moveTo]);

  const onClickCapture = useCallback((event: MouseEvent<HTMLDivElement>) => {
    if (!engine.current.suppressClick) return;
    event.preventDefault();
    event.stopPropagation();
  }, []);

  /* ------------------------------------------------- hover, focus, keys -- */

  const setPause = useCallback((source: 'hovered' | 'focused', value: boolean) => {
    engine.current[source] = value;
    startAutoplay();
  }, [startAutoplay]);

  const onKeyDown = useCallback((event: KeyboardEvent<HTMLElement>) => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    const target = event.target as HTMLElement;
    if (target.closest('input, textarea, select, [contenteditable="true"], [role="tablist"]')) return;
    event.preventDefault();
    const forwardKey = signRef.current === 1 ? 'ArrowLeft' : 'ArrowRight';
    if (event.key === forwardKey) next(); else previous();
  }, [next, previous]);

  return {
    viewportRef,
    trackRef,
    cloneCount: layout.cloneCount,
    scrollable: layout.scrollable,
    activeIndex,
    next,
    previous,
    goTo,
    rootProps: {
      onKeyDown,
      onPointerEnter: (event: PointerEvent<HTMLElement>) => { if (event.pointerType === 'mouse') setPause('hovered', true); },
      onPointerLeave: () => setPause('hovered', false),
      // Only keyboard focus pauses autoplay; a mouse click that leaves focus on an arrow must not.
      onFocus: (event: FocusEvent<HTMLElement>) => setPause('focused', event.target.matches(':focus-visible')),
      onBlur: () => setPause('focused', false)
    },
    viewportProps: {
      onPointerDown,
      onPointerMove,
      onPointerUp: endDrag,
      onPointerCancel: endDrag,
      onClickCapture
    }
  };
}
