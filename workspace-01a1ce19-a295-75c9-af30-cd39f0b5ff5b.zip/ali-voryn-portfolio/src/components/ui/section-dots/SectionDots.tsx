import type { PageSection } from '@/config/sections';
import './section-dots.css';

export type SectionDotsProps = {
  /** Sections in page order; one dot each. */
  sections: readonly PageSection[];
  /**
   * `id` of the section the dots wait for (it must be one of `sections`): they
   * stay away while it is the section on screen and slide in the moment the
   * next one takes over. Omit to show the dots from the top of the page.
   */
  showAfter?: string;
  /** Accessible name of the navigation. */
  ariaLabel: string;
  className?: string;
};

/**
 * Dots navigation fixed to the edge of the window the text starts from (right
 * in Persian, left in English): one dot per section, the section on screen is
 * highlighted and named, a click scrolls to it.
 *
 * The markup is static; `initSectionDots()` (components/ui/section-dots/section-dots.js)
 * follows the scroll position. Below 1024px of width (or 480px of height) the
 * navigation does not exist: it is not displayed and nothing is measured.
 *
 *   --section-dots-accent   colour of the current dot (default var(--accent))
 *   --section-dots-offset   distance from the window edge (default 16px)
 */
export function SectionDots({ sections, showAfter, ariaLabel, className }: SectionDotsProps) {
  return (
    <nav
      className={className ? `section-dots ${className}` : 'section-dots'}
      data-section-dots=""
      data-show-after={showAfter}
      data-visible={showAfter ? 'false' : 'true'}
      aria-label={ariaLabel}
    >
      <ul className="section-dots__list">
        {sections.map(section => (
          <li key={section.id}>
            <a className="section-dots__link" href={`#${section.id}`} data-section={section.id}>
              <span className="section-dots__dot" aria-hidden="true" />
              <span className="section-dots__label" data-fa={section.label.fa} data-en={section.label.en}>{section.label.fa}</span>
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
