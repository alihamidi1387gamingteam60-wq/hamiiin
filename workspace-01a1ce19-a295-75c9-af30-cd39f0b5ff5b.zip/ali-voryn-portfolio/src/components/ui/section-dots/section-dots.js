/** Same condition as the media query in section-dots.css, negated. */
const FITS_QUERY = '(min-width: 1024px) and (min-height: 480px)';
/**
 * A later section has to be ahead by this much to take over. When two sections are
 * both (almost) whole on screen — a tall window — the earlier one keeps the dot
 * until a tenth of it has left, instead of losing it on the first pixel of scroll.
 */
const LEAD = 0.1;
/** A section counts as whole on screen from this share on. */
const WHOLE = 0.99;
/** How long a clicked link may take to bring its section on screen before the click is forgotten, in ms. */
const TRAVEL_TIME = 3000;
/** How long the name of a newly reached section stays open, in ms. */
const ANNOUNCE_TIME = 1500;

const started = new WeakSet();

/**
 * Drives one dots navigation: marks the dot of the section on screen
 * (`aria-current`), shows the navigation once the page has left its gate
 * section (`data-visible`) and names a section when it is reached. Scrolling
 * itself is left to the links (`href="#id"`).
 *
 * "The section on screen" is the one that fills the most of what it could fill:
 * its visible height divided by its own height (or by the window, when it is
 * taller). A short section therefore owns the screen as soon as most of it has
 * come in, and keeps it until most of it has left — wherever it sits in the
 * window, and whether the page was scrolled or jumped to it. At the very end of
 * the page the last section owns the screen, however little room it had to move up.
 *
 * A click on a link to a section (a dot, the header menu) is remembered: once
 * that section is whole on screen it owns the dot until the page is scrolled
 * away from it — so on a tall window, where two sections fit together, the dot
 * that was clicked is the one that lights up.
 *
 * One measurement per animation frame while scrolling (a handful of
 * `getBoundingClientRect()` reads, no writes in between), and nothing at all
 * while the navigation does not fit.
 *
 * @param {HTMLElement} nav the `[data-section-dots]` element rendered by `<SectionDots>`
 */
function runSectionDots(nav) {
  const links = new Map();
  for (const link of nav.querySelectorAll('a[data-section]')) links.set(link.dataset.section, link);
  const sections = [...links.keys()].map(id => document.getElementById(id)).filter(Boolean);
  const gateId = nav.dataset.showAfter || null;
  const fits = window.matchMedia(FITS_QUERY);

  let current = null;
  /** Section asked for by a click, and whether the scroll has brought it whole on screen yet. */
  let wanted = null;
  let wantedReached = false;
  let wantedTimer = 0;
  let announceTimer = 0;
  let frame = 0;
  let listening = false;

  function announce(link) {
    window.clearTimeout(announceTimer);
    for (const other of links.values()) delete other.dataset.announce;
    if (!link || nav.dataset.visible !== 'true') return;
    link.dataset.announce = 'true';
    announceTimer = window.setTimeout(() => delete link.dataset.announce, ANNOUNCE_TIME);
  }

  function setVisible(visible) {
    if ((nav.dataset.visible === 'true') === visible) return false;
    nav.dataset.visible = String(visible);
    return true;
  }

  function setCurrent(id) {
    const changed = id !== current;
    if (changed) {
      current = id;
      for (const [section, link] of links) {
        if (section === id) link.setAttribute('aria-current', 'true');
        else link.removeAttribute('aria-current');
      }
    }
    const shown = setVisible(!gateId || id !== gateId);
    if (changed || shown) announce(links.get(id));
  }

  function measure() {
    frame = 0;
    const bottom = window.innerHeight;
    let best = null;
    let bestShare = 0;
    let wantedShare = 0;
    for (const section of sections) {
      const rect = section.getBoundingClientRect();
      const visible = Math.min(rect.bottom, bottom) - Math.max(rect.top, 0);
      if (visible <= 0 || rect.height <= 0) continue;
      const share = visible / Math.min(rect.height, bottom);
      if (section.id === wanted) wantedShare = share;
      if (!best || share > bestShare + LEAD) {
        best = section;
        bestShare = share;
      }
    }

    if (wanted) {
      if (wantedShare >= WHOLE) {
        wantedReached = true;
        setCurrent(wanted);
        return;
      }
      // It was on screen and the page has been scrolled away from it: back to the plain rule.
      if (wantedReached) forgetWanted();
    }

    const scrolled = window.scrollY;
    const last = sections[sections.length - 1];
    if (last && scrolled > 0 && scrolled + bottom >= document.documentElement.scrollHeight - 2) setCurrent(last.id);
    else if (best) setCurrent(best.id);
  }

  function forgetWanted() {
    window.clearTimeout(wantedTimer);
    wanted = null;
    wantedReached = false;
  }

  /** A click on any link to one of the sections (`href="#id"`), wherever the link is on the page. */
  function onLinkClick(event) {
    const link = event.target instanceof Element ? event.target.closest('a[href^="#"]') : null;
    const id = link ? link.getAttribute('href').slice(1) : '';
    if (!id || !links.has(id)) return;
    forgetWanted();
    wanted = id;
    // If the section never gets whole on screen (it is taller than the window can show), the click is dropped.
    wantedTimer = window.setTimeout(() => {
      if (!wantedReached) forgetWanted();
    }, TRAVEL_TIME);
    schedule();
  }

  function schedule() {
    if (!frame) frame = window.requestAnimationFrame(measure);
  }

  function update() {
    if (fits.matches && !listening) {
      listening = true;
      window.addEventListener('scroll', schedule, { passive: true });
      window.addEventListener('resize', schedule, { passive: true });
      document.addEventListener('click', onLinkClick);
    } else if (!fits.matches && listening) {
      listening = false;
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', schedule);
      document.removeEventListener('click', onLinkClick);
      forgetWanted();
    }
    if (fits.matches) schedule();
    else if (gateId) setVisible(false);
  }

  fits.addEventListener('change', update);
  // Section heights change with the language (text length) and once fonts and images are in.
  document.addEventListener('portfolio:languagechange', schedule);
  window.addEventListener('load', schedule, { once: true });
  update();
}

/**
 * Starts every `<SectionDots>` under `root` that is not running yet.
 *
 * @param {ParentNode} [root]
 */
export function initSectionDots(root = document) {
  for (const nav of root.querySelectorAll('[data-section-dots]')) {
    if (started.has(nav)) continue;
    started.add(nav);
    runSectionDots(nav);
  }
}
