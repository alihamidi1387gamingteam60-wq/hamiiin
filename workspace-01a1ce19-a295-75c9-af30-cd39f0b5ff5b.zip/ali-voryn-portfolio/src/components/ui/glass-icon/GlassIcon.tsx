import { useId } from 'react';
import type { ReactNode } from 'react';
import './glass-icon.css';

export type GlassIconName = 'cart' | 'gear';

type GlassIconShape = {
  /** Coloured shape that sits behind the glass. */
  back: ReactNode;
  /** Outline of the glass pane; the colour behind it is seen blurred through it. */
  pane: string;
  /** Solid details drawn on top of the pane. */
  details?: ReactNode;
};

const GEAR_PANE = 'M13.52 6.00L14.11 2.73L17.89 2.73L18.48 6.00A10.3 10.3 0 0 1 21.31 7.18L24.05 5.28L26.72 7.95L24.82 10.69A10.3 10.3 0 0 1 26.00 13.52L29.27 14.11L29.27 17.89L26.00 18.48A10.3 10.3 0 0 1 24.82 21.31L26.72 24.05L24.05 26.72L21.31 24.82A10.3 10.3 0 0 1 18.48 26.00L17.89 29.27L14.11 29.27L13.52 26.00A10.3 10.3 0 0 1 10.69 24.82L7.95 26.72L5.28 24.05L7.18 21.31A10.3 10.3 0 0 1 6.00 18.48L2.73 17.89L2.73 14.11L6.00 13.52A10.3 10.3 0 0 1 7.18 10.69L5.28 7.95L7.95 5.28L10.69 7.18A10.3 10.3 0 0 1 13.52 6.00ZM16 11.2a4.8 4.8 0 1 0 0 9.6a4.8 4.8 0 1 0 0-9.6Z';
const CART_PANE = 'M7.4 9.2h19.9a1.2 1.2 0 0 1 1.17 1.48l-2.3 9.6a2.6 2.6 0 0 1-2.53 2H12.1a2.6 2.6 0 0 1-2.53-2L7.4 9.2Z';

/** To add an icon: one entry here (32×32 grid) and its name in `GlassIconName`. */
const SHAPES: Record<GlassIconName, GlassIconShape> = {
  gear: {
    back: <circle cx="16" cy="16" r="7.6" />,
    pane: GEAR_PANE
  },
  cart: {
    back: <circle cx="21.5" cy="9.5" r="7" />,
    pane: CART_PANE,
    details: (
      <>
        <path className="glass-icon__line" d="M2.6 5.2h2.7a1.4 1.4 0 0 1 1.36 1.07L7.4 9.2" />
        <path className="glass-icon__line glass-icon__line--soft" d="M13.2 13.4v4.6M17.6 13.4v4.6M22 13.4v4.6" />
        <circle className="glass-icon__solid" cx="12.8" cy="26.6" r="2" />
        <circle className="glass-icon__solid" cx="22.6" cy="26.6" r="2" />
      </>
    )
  }
};

export type GlassIconProps = {
  name: GlassIconName;
  className?: string;
};

/**
 * Icon in the glassmorphism style: a shape in the theme colours with a frosted
 * glass pane over it. Decorative (`aria-hidden`) — name the control that holds it.
 * Size it with `width`/`height` or `font-size` (it is 1em by default).
 *
 *   --glass-icon-from / --glass-icon-to   colours behind the glass (default the theme accents)
 */
export function GlassIcon({ name, className }: GlassIconProps) {
  const id = `glass-icon-${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const shape = SHAPES[name];
  return (
    <svg className={className ? `glass-icon ${className}` : 'glass-icon'} viewBox="0 0 32 32" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id={`${id}-tint`} x1="0" y1="0" x2="1" y2="1">
          <stop className="glass-icon__from" offset="0" />
          <stop className="glass-icon__to" offset="1" />
        </linearGradient>
        <linearGradient id={`${id}-pane`} x1="0.1" y1="0" x2="0.9" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.52" />
          <stop offset="0.58" stopColor="#fff" stopOpacity="0.16" />
          <stop offset="1" stopColor="#fff" stopOpacity="0.07" />
        </linearGradient>
        <linearGradient id={`${id}-edge`} x1="0.1" y1="0" x2="0.9" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.95" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0.28" />
          <stop offset="1" stopColor="#fff" stopOpacity="0.58" />
        </linearGradient>
        <filter id={`${id}-frost`} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2.3" />
        </filter>
        <clipPath id={`${id}-clip`}>
          <path clipRule="evenodd" d={shape.pane} />
        </clipPath>
      </defs>
      <g fill={`url(#${id}-tint)`}>{shape.back}</g>
      <g clipPath={`url(#${id}-clip)`}>
        <rect className="glass-icon__shade" width="32" height="32" />
        <g fill={`url(#${id}-tint)`} filter={`url(#${id}-frost)`} opacity="0.88" transform="translate(16 16) scale(1.28) translate(-16 -16)">{shape.back}</g>
      </g>
      <path fillRule="evenodd" d={shape.pane} fill={`url(#${id}-pane)`} stroke={`url(#${id}-edge)`} strokeWidth="0.9" strokeLinejoin="round" />
      {shape.details}
    </svg>
  );
}
