import type { ReactNode } from 'react';
import type { Localized } from '@/hooks/use-locale';
import './floating-dock.css';

export type FloatingDockProps = {
  /** Unique id; the drawer gets `${id}-panel`. */
  id: string;
  /** Icon of the round button (decorative; `label` names the button). */
  icon: ReactNode;
  /** Accessible name of the button and of the drawer. */
  label: Localized;
  /** Controls shown in the drawer. */
  children: ReactNode;
  className?: string;
};

/**
 * Round button fixed to the bottom corner of the window, floating gently while
 * its icon turns. Hovering it (or tapping it, or reaching it with the keyboard)
 * slides a small drawer open above it. It sits on the side the text ends on:
 * bottom left in Persian, bottom right in English.
 *
 * Opening on hover is CSS; `initFloatingDocks()` (components/ui/floating-dock/floating-dock.js)
 * adds tap, Escape and click-outside. A control in the drawer that carries
 * `data-dock-close` closes the drawer when it is used.
 *
 *   --floating-dock-offset   distance from the window edges (default 22px)
 *   --floating-dock-size     diameter of the button (default 54px)
 */
export function FloatingDock({ id, icon, label, children, className }: FloatingDockProps) {
  const panelId = `${id}-panel`;
  return (
    <div className={className ? `floating-dock ${className}` : 'floating-dock'} id={id} data-floating-dock="" data-open="false">
      {/* The button comes first so the keyboard reaches it, then the drawer it opens. */}
      <button className="floating-dock__trigger" type="button" aria-expanded="false" aria-controls={panelId}>
        <span className="floating-dock__float">
          <span className="floating-dock__icon">{icon}</span>
        </span>
        <span className="visually-hidden" data-fa={label.fa} data-en={label.en}>{label.fa}</span>
      </button>
      <div className="floating-dock__panel" id={panelId}>
        <div className="floating-dock__tray">{children}</div>
      </div>
    </div>
  );
}
