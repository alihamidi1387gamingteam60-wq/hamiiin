const started = new WeakSet();

/**
 * Tap, keyboard and click-outside behaviour of one `<FloatingDock>`. Opening on
 * hover needs no script (floating-dock.css); this adds what a touch screen and a
 * keyboard need: the button pins the drawer open or closes it, Escape and a
 * click elsewhere close it, and so does using a control marked `data-dock-close`.
 *
 * @param {HTMLElement} dock the `[data-floating-dock]` element
 */
function runFloatingDock(dock) {
  const trigger = dock.querySelector('.floating-dock__trigger');
  if (!trigger) return;

  const isOpen = () => dock.dataset.open === 'true';

  function setOpen(open) {
    dock.dataset.open = String(open);
    trigger.setAttribute('aria-expanded', String(open));
  }

  trigger.addEventListener('click', () => setOpen(!isOpen()));
  dock.addEventListener('click', event => {
    if (event.target instanceof Element && event.target.closest('[data-dock-close]')) setOpen(false);
  });
  document.addEventListener('click', event => {
    if (isOpen() && event.target instanceof Node && !dock.contains(event.target)) setOpen(false);
  });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !isOpen()) return;
    setOpen(false);
    if (dock.contains(document.activeElement)) trigger.focus();
  });
}

/**
 * Starts every `<FloatingDock>` under `root` that is not running yet.
 *
 * @param {ParentNode} [root]
 */
export function initFloatingDocks(root = document) {
  for (const dock of root.querySelectorAll('[data-floating-dock]')) {
    if (started.has(dock)) continue;
    started.add(dock);
    runFloatingDock(dock);
  }
}
