import { BrandLogo } from '@/components/brand/BrandLogo';
import { GlassIcon } from '@/components/ui/glass-icon/GlassIcon';
import { HOME_SECTIONS } from '@/config/sections';
import './nav-scribble.css';
import './header-actions.css';

/** The header links to every section below the opening header. */
const NAV_SECTIONS = HOME_SECTIONS.slice(1);

export function SiteHeader() {
  return (
    <header className="site-header">
      <nav className="nav-shell" aria-label="منوی اصلی">
        <BrandLogo />
        <button className="mobile-toggle" type="button" aria-label="باز کردن منو" aria-expanded="false" aria-controls="primary-links">
          <span /><span /><span />
        </button>
        <div className="nav-links" id="primary-links">
          {NAV_SECTIONS.map(section => (
            <a key={section.id} href={`#${section.id}`} data-fa={section.label.fa} data-en={section.label.en}>{section.label.fa}</a>
          ))}
          {/* Stroke of the hover effect; the path is written by components/layout/scribble-loop.js. */}
          <svg className="nav-scribble" aria-hidden="true" focusable="false">
            <g>
              <path className="nav-scribble__glow" />
              <path className="nav-scribble__line" />
            </g>
          </svg>
        </div>
        <div className="nav-actions">
          <button className="cart-button" type="button">
            <GlassIcon name="cart" />
            <span className="visually-hidden" data-fa="سبد خرید" data-en="Shopping cart">سبد خرید</span>
          </button>
          <button className="auth-button" type="button">
            <span data-fa="ورود" data-en="Log in">ورود</span>
            <i className="auth-button__divider" aria-hidden="true" />
            <span className="auth-button__more" data-fa="ثبت نام" data-en="Sign up">ثبت نام</span>
          </button>
        </div>
      </nav>
    </header>
  );
}
