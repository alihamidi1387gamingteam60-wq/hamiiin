const EVENT_LANGUAGE = 'portfolio:languagechange';
const MOBILE_QUERY = '(max-width: 680px)'; // same breakpoint as the header styles in globals.css

const LABELS = {
  open: { fa: 'باز کردن منو', en: 'Open menu' },
  close: { fa: 'بستن منو', en: 'Close menu' }
};

/**
 * Hamburger menu of the site header on phones: the button opens and closes the
 * link list, and the list also closes on Escape, on a tap outside, after
 * picking a link and when the window grows past the phone breakpoint.
 */
export function initMobileMenu() {
  const button = document.querySelector('.mobile-toggle');
  const menu = document.getElementById('primary-links');
  if (!button || !menu) return;

  const isOpen = () => button.getAttribute('aria-expanded') === 'true';

  function updateLabel() {
    const language = document.documentElement.lang === 'en' ? 'en' : 'fa';
    button.setAttribute('aria-label', LABELS[isOpen() ? 'close' : 'open'][language]);
  }

  function setOpen(open) {
    button.setAttribute('aria-expanded', String(open));
    menu.classList.toggle('is-open', open);
    updateLabel();
  }

  button.addEventListener('click', () => setOpen(!isOpen()));
  menu.addEventListener('click', event => {
    if (event.target instanceof Element && event.target.closest('a')) setOpen(false);
  });
  document.addEventListener('click', event => {
    if (isOpen() && event.target instanceof Node && !button.contains(event.target) && !menu.contains(event.target)) setOpen(false);
  });
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !isOpen()) return;
    setOpen(false);
    button.focus();
  });
  window.matchMedia(MOBILE_QUERY).addEventListener('change', event => {
    if (!event.matches) setOpen(false);
  });
  document.addEventListener(EVENT_LANGUAGE, updateLabel);
  updateLabel();
}
