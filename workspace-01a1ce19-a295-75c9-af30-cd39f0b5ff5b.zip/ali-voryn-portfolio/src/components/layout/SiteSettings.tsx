import { FloatingDock } from '@/components/ui/floating-dock/FloatingDock';
import { GlassIcon } from '@/components/ui/glass-icon/GlassIcon';
import './site-settings.css';

/**
 * Site settings — language and colour theme — behind the floating gear in the
 * bottom corner of the window. The two buttons are driven by
 * features/theme/theme-language.js through their ids.
 */
export function SiteSettings() {
  return (
    <FloatingDock id="siteSettings" icon={<GlassIcon name="gear" />} label={{ fa: 'تنظیمات سایت', en: 'Site settings' }}>
      <button className="language-button" id="languageToggle" type="button" aria-label="تغییر زبان به انگلیسی">
        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M3.5 12h17M12 3c2.3 2.4 3.4 5.4 3.4 9s-1.1 6.6-3.4 9c-2.3-2.4-3.4-5.4-3.4-9S9.7 5.4 12 3Z" /></svg>
        <span id="languageLabel">EN</span>
      </button>
      <button className="palette-button" id="openTheme" type="button" aria-label="ساخت رنگ‌بندی" aria-haspopup="dialog" aria-controls="themeDialog" data-dock-close="">
        <span className="palette-icon" aria-hidden="true"><i /><i /><i /></span>
      </button>
    </FloatingDock>
  );
}
