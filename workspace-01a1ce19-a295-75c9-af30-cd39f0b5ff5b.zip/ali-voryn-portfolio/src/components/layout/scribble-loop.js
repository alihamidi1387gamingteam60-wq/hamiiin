/**
 * Scribble loop: a hand-drawn loop circles the hovered menu item and, when the
 * pointer moves to another item, runs there along one continuous stroke
 * (loop → line through the labels → next loop). Idea: "Scribble Loop Nav" by Originkit.
 *
 * How this version stays cheap:
 *  - the whole stroke (every loop and every connector) is one SVG path that is
 *    built once per layout — not once per frame;
 *  - a frame only moves the visible window of that path: two style values
 *    (stroke-dasharray / stroke-dashoffset), no path data, no layout reads;
 *  - the animation loop runs only while the stroke is moving and stops at rest;
 *  - geometry is re-measured by a ResizeObserver, not polled.
 */

const EVENT_LANGUAGE = 'portfolio:languagechange';
const ENABLED_QUERY = '(min-width: 681px) and (hover: hover) and (pointer: fine)'; // 681px: above the phone menu breakpoint
const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';

const TAU = Math.PI * 2;
const DEG = Math.PI / 180;

/** Shape of one loop. Lengths are multiples of the label's font size. */
const SHAPE = {
  padX: 1.3, // room between the label and the loop on each side (also capped by the gap between items)
  radiusY: 1.32, // half the loop height
  startAngle: 240, // the pen lands top-left …
  sweep: 310, // … and goes round clockwise
  spiral: 0.04, // the loop opens slightly, so its ends cross instead of meeting
  leadIn: 1.3, // stroke rising from inside the loop into its start
  curl: 0.75, // flick at the end of the loop
  topFlatten: 0.08,
  bottomBulge: 0.06,
  tilt: -2, // degrees
  wobble: 0.7, // hand-drawn irregularity, 0 = perfect ellipse
  connectorSag: 0.15,
  seed: 7
};

const LOOP_POINTS = 64;
const LEAD_POINTS = 10;
const CURL_POINTS = 8;
const CONNECTOR_POINTS = 18;

/** Durations in ms. */
const TIMING = {
  draw: 420, // drawing or wiping one loop
  move: 520, // travelling to the neighbouring item
  skipExtra: 0.3, // extra share of `move` per additional item skipped
  stretch: 0.14 // how far the rear end lags behind the front, as a share of the travel time
};

const clamp = (value, min, max) => (value < min ? min : value > max ? max : value);

/** Small seeded generator, so every item keeps its own wobble between rebuilds. */
function createRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = state;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function normalize(x, y) {
  const length = Math.hypot(x, y) || 1;
  return [x / length, y / length];
}

function pushQuadratic(xs, ys, ax, ay, cx, cy, bx, by, steps, skipFirst) {
  for (let i = skipFirst ? 1 : 0; i <= steps; i++) {
    const t = i / steps;
    const u = 1 - t;
    xs.push(u * u * ax + 2 * u * t * cx + t * t * bx);
    ys.push(u * u * ay + 2 * u * t * cy + t * t * by);
  }
}

function pushCubic(xs, ys, a, b, c, d, steps) {
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const u = 1 - t;
    const w0 = u * u * u;
    const w1 = 3 * u * u * t;
    const w2 = 3 * u * t * t;
    const w3 = t * t * t;
    xs.push(w0 * a[0] + w1 * b[0] + w2 * c[0] + w3 * d[0]);
    ys.push(w0 * a[1] + w1 * b[1] + w2 * c[1] + w3 * d[1]);
  }
}

/**
 * Builds the stroke for a row of boxes laid out left to right.
 * Returns the path data and, in px along the path, where every item starts and ends:
 * item i spans bounds[2i] … bounds[2i + 1]; the connector to the next item follows it.
 *
 * @param {{ x: number, y: number, w: number, h: number }[]} boxes
 * @param {number} fontSize
 * @param {number} padX
 * @param {(x: number) => number} mapX final x of a point (mirrors the stroke for right-to-left rows)
 */
function buildChain(boxes, fontSize, padX, mapX) {
  const xs = [];
  const ys = [];
  const marks = []; // point index of every item start and end
  const exits = []; // end point and direction of every item
  const f = fontSize;

  boxes.forEach((box, index) => {
    const random = createRandom(SHAPE.seed * 977 + index * 131 + 1);
    const phase1 = random() * TAU;
    const phase2 = random() * TAU;
    const tiltJitter = random() - 0.5;

    const centerX = box.x + box.w / 2;
    const centerY = box.y + box.h / 2;
    const radiusX = box.w / 2 + padX;
    const radiusY = f * SHAPE.radiusY;
    const from = SHAPE.startAngle * DEG;
    const to = from + SHAPE.sweep * DEG;
    const tilt = (SHAPE.tilt + tiltJitter * 4 * SHAPE.wobble) * DEG;
    const cosTilt = Math.cos(tilt);
    const sinTilt = Math.sin(tilt);

    const at = (angle, progress) => {
      const radius = 1
        + SHAPE.wobble * (0.035 * Math.sin(2 * angle + phase1) + 0.022 * Math.sin(3 * angle + phase2))
        + SHAPE.spiral * (progress - 0.5);
      const sin = Math.sin(angle);
      const cos = Math.cos(angle);
      const dx = radiusX * radius * cos;
      let dy = radiusY * radius * sin;
      if (sin < 0) dy *= 1 + SHAPE.topFlatten * sin;
      if (sin > 0 && cos > 0) dy += radiusY * SHAPE.bottomBulge * 2.6 * sin * cos * cos;
      return [centerX + dx * cosTilt - dy * sinTilt, centerY + dx * sinTilt + dy * cosTilt];
    };

    // lead-in: from inside the loop, rising into the tangent of its start
    const start = at(from, 0);
    const afterStart = at(from + 0.01, 0);
    const startTangent = normalize(afterStart[0] - start[0], afterStart[1] - start[1]);
    const lead = f * SHAPE.leadIn;
    const entry = [start[0] - 0.6 * lead, start[1] + 0.8 * lead];
    const entryControl = [start[0] - startTangent[0] * lead * 0.45, start[1] - startTangent[1] * lead * 0.45];
    const entryDirection = normalize(entryControl[0] - entry[0], entryControl[1] - entry[1]);

    if (index > 0) {
      // connector: from the previous flick, almost straight through the labels, into this lead-in
      const previous = exits[index - 1];
      const distance = Math.hypot(entry[0] - previous.point[0], entry[1] - previous.point[1]);
      const sag = f * SHAPE.connectorSag;
      pushCubic(
        xs, ys,
        previous.point,
        [previous.point[0] + previous.direction[0] * distance * 0.35, previous.point[1] + previous.direction[1] * distance * 0.35 + sag],
        [entry[0] - entryDirection[0] * distance * 0.1, entry[1] - entryDirection[1] * distance * 0.1 + sag],
        entry,
        CONNECTOR_POINTS
      );
      marks.push(xs.length - 1);
    } else {
      xs.push(entry[0]);
      ys.push(entry[1]);
      marks.push(0);
    }

    pushQuadratic(xs, ys, entry[0], entry[1], entryControl[0], entryControl[1], start[0], start[1], LEAD_POINTS, true);
    for (let k = 1; k <= LOOP_POINTS; k++) {
      const progress = k / LOOP_POINTS;
      const point = at(from + (to - from) * progress, progress);
      xs.push(point[0]);
      ys.push(point[1]);
    }

    // flick: on along the loop for a moment, then off to the side
    const end = at(to, 1);
    const beforeEnd = at(to - 0.01, 1);
    const endTangent = normalize(end[0] - beforeEnd[0], end[1] - beforeEnd[1]);
    const curl = f * SHAPE.curl;
    const exitControl = [end[0] + endTangent[0] * curl * 0.45, end[1] + endTangent[1] * curl * 0.45];
    const exit = [end[0] + curl * 0.95, end[1] - curl * 0.45];
    pushQuadratic(xs, ys, end[0], end[1], exitControl[0], exitControl[1], exit[0], exit[1], CURL_POINTS, true);
    marks.push(xs.length - 1);
    exits.push({ point: exit, direction: normalize(exit[0] - exitControl[0], exit[1] - exitControl[1]) });
  });

  // Lengths are measured on the rounded points that go into the path, so they match what the browser draws.
  const lengths = new Float32Array(xs.length);
  let data = '';
  let previousX = 0;
  let previousY = 0;
  for (let i = 0; i < xs.length; i++) {
    const x = Math.round(mapX(xs[i]) * 10) / 10;
    const y = Math.round(ys[i] * 10) / 10;
    lengths[i] = i === 0 ? 0 : lengths[i - 1] + Math.hypot(x - previousX, y - previousY);
    data += `${i === 0 ? 'M' : 'L'}${x} ${y}`;
    previousX = x;
    previousY = y;
  }

  return { data, bounds: marks.map(mark => lengths[mark]), total: lengths[lengths.length - 1] };
}

/**
 * Attaches the effect to a row of items.
 *
 * @param {HTMLElement} container positioned element that holds the items and the `<svg>`
 * @param {{ itemSelector?: string, svgSelector?: string, activeClass?: string }} [options]
 * @returns {() => void} detach function
 */
export function createScribbleLoop(container, { itemSelector = 'a', svgSelector = '.nav-scribble', activeClass = 'has-scribble' } = {}) {
  const svg = container.querySelector(svgSelector);
  const group = svg?.querySelector('g');
  const paths = group ? [...group.querySelectorAll('path')] : [];
  if (!svg || !group || paths.length === 0) return () => {};

  const enabledQuery = window.matchMedia(ENABLED_QUERY);
  const reducedQuery = window.matchMedia(REDUCED_MOTION_QUERY);

  let items = [];
  let chain = null;
  let enabled = false;
  let frame = 0;
  let rebuildFrame = 0;
  let painted = false;
  let pointerInside = false;
  let target = -1;
  let hidden = true;

  // The two ends of the visible stroke. Each is a Hermite tween along the path whose
  // endpoints are stored in chain units (item i = 2i … 2i + 1), so they survive a rebuild.
  const head = { fromU: 0, toU: 0, start: 0, duration: 0, velocity: 0 };
  const tail = { fromU: 0, toU: 0, start: 0, duration: 0, velocity: 0 };

  function unitToLength(unit) {
    const last = chain.bounds.length - 1;
    const clamped = clamp(unit, 0, last);
    const index = Math.min(Math.floor(clamped), last - 1);
    return chain.bounds[index] + (clamped - index) * (chain.bounds[index + 1] - chain.bounds[index]);
  }

  function lengthToUnit(length) {
    const { bounds } = chain;
    if (length <= bounds[0]) return 0;
    for (let index = 0; index < bounds.length - 1; index++) {
      if (length < bounds[index + 1]) return index + (length - bounds[index]) / (bounds[index + 1] - bounds[index] || 1);
    }
    return bounds.length - 1;
  }

  function positionOf(end, time) {
    const to = unitToLength(end.toU);
    if (end.duration <= 0 || time >= end.start + end.duration) return to;
    const from = unitToLength(end.fromU);
    if (time <= end.start) return from;
    const t = (time - end.start) / end.duration;
    const t2 = t * t;
    const t3 = t2 * t;
    return from * (2 * t3 - 3 * t2 + 1) + to * (3 * t2 - 2 * t3) + end.velocity * end.duration * (t3 - 2 * t2 + t);
  }

  function place(end, unit, time) {
    end.fromU = unit;
    end.toU = unit;
    end.start = time;
    end.duration = 0;
    end.velocity = 0;
  }

  /** Retargets an end from wherever it is, keeping its speed so the stroke never jerks. */
  function aim(end, unit, duration, delay, time) {
    if (duration <= 0) {
      place(end, unit, time);
      return;
    }
    const current = positionOf(end, time);
    const velocity = (current - positionOf(end, time - 8)) / 8;
    const moving = Math.abs(velocity) > 0.001;
    end.fromU = lengthToUnit(current);
    end.toU = unit;
    end.duration = duration;
    end.velocity = moving ? velocity : 0;
    end.start = moving ? time : time + delay;
  }

  function paint(time) {
    const a = positionOf(tail, time);
    const b = positionOf(head, time);
    const length = Math.abs(b - a);
    if (length < 0.5) {
      if (painted) {
        group.style.visibility = 'hidden';
        painted = false;
      }
      return;
    }
    // One dash of the visible length, shifted to where the stroke currently is.
    const gap = chain.total + 64;
    group.style.strokeDasharray = `${length.toFixed(1)} ${gap.toFixed(1)}`;
    group.style.strokeDashoffset = (length + gap - Math.min(a, b)).toFixed(1);
    if (!painted) {
      group.style.visibility = 'visible';
      painted = true;
    }
  }

  function tick() {
    const time = performance.now();
    paint(time);
    const moving = time < head.start + head.duration || time < tail.start + tail.duration;
    frame = moving ? requestAnimationFrame(tick) : 0;
  }

  function run() {
    if (!frame) frame = requestAnimationFrame(tick);
  }

  function show(index) {
    if (!enabled || !chain || index < 0) return;
    const time = performance.now();
    const reduced = reducedQuery.matches;
    const drawTime = reduced ? 0 : TIMING.draw;
    const tailAt = positionOf(tail, time);

    if (hidden) {
      hidden = false;
      if (Math.abs(positionOf(head, time) - tailAt) < 1) {
        // nothing on screen: draw the loop from its own start
        place(tail, 2 * index, time);
        place(head, 2 * index, time);
        aim(head, 2 * index + 1, drawTime, 0, time);
        target = index;
        run();
        return;
      }
      // caught in the middle of being wiped away: carry on from what is still visible
      target = -1;
    }
    if (index === target) return;

    const tailUnit = lengthToUnit(tailAt);
    const steps = Math.max(1, Math.abs(index - (target >= 0 ? target : Math.floor(tailUnit / 2))));
    const moveTime = reduced ? 0 : TIMING.move * (1 + TIMING.skipExtra * (steps - 1));
    const lag = moveTime * TIMING.stretch;
    if (2 * index > tailUnit) {
      aim(head, 2 * index + 1, moveTime, 0, time);
      aim(tail, 2 * index, moveTime, lag, time);
    } else {
      aim(tail, 2 * index, moveTime, 0, time);
      aim(head, 2 * index + 1, moveTime, lag, time);
    }
    target = index;
    run();
  }

  function hide() {
    if (hidden || !chain) return;
    hidden = true;
    aim(tail, head.toU, reducedQuery.matches ? 0 : TIMING.draw, 0, performance.now());
    run();
  }

  function rebuild() {
    rebuildFrame = 0;
    if (!enabled) return;
    items = [...container.querySelectorAll(itemSelector)];
    if (items.length === 0) {
      chain = null;
      return;
    }
    const width = container.clientWidth;
    const style = getComputedStyle(container);
    const rightToLeft = style.direction === 'rtl';
    const fontSize = parseFloat(getComputedStyle(items[0]).fontSize) || 13;
    const gap = parseFloat(style.columnGap) || fontSize;
    const padX = Math.min(fontSize * SHAPE.padX, Math.max(6, gap * 0.46));

    // Measured in reading order: for right-to-left rows the row is mirrored here and mirrored
    // back when the path is written, so the pen always moves the way the language is written.
    const boxes = items.map(item => ({
      x: rightToLeft ? width - item.offsetLeft - item.offsetWidth : item.offsetLeft,
      y: item.offsetTop,
      w: item.offsetWidth,
      h: item.offsetHeight
    }));
    chain = buildChain(boxes, fontSize, padX, rightToLeft ? x => width - x : x => x);
    for (const path of paths) path.setAttribute('d', chain.data);
    paint(performance.now());
  }

  function scheduleRebuild() {
    if (enabled && !rebuildFrame) rebuildFrame = requestAnimationFrame(rebuild);
  }

  function indexOf(node) {
    return node instanceof Element ? items.indexOf(node.closest(itemSelector)) : -1;
  }

  function focusedIndex() {
    const active = document.activeElement;
    return active instanceof Element && container.contains(active) && active.matches(':focus-visible') ? indexOf(active) : -1;
  }

  function onPointerOver(event) {
    if (event.pointerType === 'touch') return;
    pointerInside = true;
    const index = indexOf(event.target);
    if (index >= 0) show(index);
  }

  function onPointerLeave() {
    pointerInside = false;
    const index = focusedIndex();
    if (index >= 0) show(index);
    else hide();
  }

  function onFocusIn() {
    const index = focusedIndex();
    if (index >= 0) show(index);
  }

  function onFocusOut(event) {
    if (pointerInside || (event.relatedTarget instanceof Node && container.contains(event.relatedTarget))) return;
    hide();
  }

  function setEnabled(next) {
    if (next === enabled) return;
    enabled = next;
    container.classList.toggle(activeClass, enabled);
    if (enabled) {
      rebuild();
      return;
    }
    cancelAnimationFrame(frame);
    cancelAnimationFrame(rebuildFrame);
    frame = 0;
    rebuildFrame = 0;
    hidden = true;
    target = -1;
    painted = false;
    pointerInside = false;
    group.style.visibility = 'hidden';
    place(head, 0, 0);
    place(tail, 0, 0);
  }

  const onQueryChange = () => setEnabled(enabledQuery.matches);
  const resizeObserver = new ResizeObserver(scheduleRebuild);
  resizeObserver.observe(container);
  for (const item of container.querySelectorAll(itemSelector)) resizeObserver.observe(item);

  container.addEventListener('pointerover', onPointerOver);
  container.addEventListener('pointerleave', onPointerLeave);
  container.addEventListener('focusin', onFocusIn);
  container.addEventListener('focusout', onFocusOut);
  enabledQuery.addEventListener('change', onQueryChange);
  document.addEventListener(EVENT_LANGUAGE, scheduleRebuild);
  document.fonts?.ready.then(scheduleRebuild);

  group.style.visibility = 'hidden';
  setEnabled(enabledQuery.matches);

  return () => {
    setEnabled(false);
    resizeObserver.disconnect();
    container.removeEventListener('pointerover', onPointerOver);
    container.removeEventListener('pointerleave', onPointerLeave);
    container.removeEventListener('focusin', onFocusIn);
    container.removeEventListener('focusout', onFocusOut);
    enabledQuery.removeEventListener('change', onQueryChange);
    document.removeEventListener(EVENT_LANGUAGE, scheduleRebuild);
  };
}

/** Scribble loop on the links of the site header. */
export function initNavScribble() {
  const menu = document.getElementById('primary-links');
  if (menu) createScribbleLoop(menu);
}
