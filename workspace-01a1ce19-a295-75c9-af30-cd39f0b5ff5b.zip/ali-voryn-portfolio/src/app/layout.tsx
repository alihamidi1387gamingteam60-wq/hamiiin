import type { Metadata, Viewport } from 'next';
import './globals.css';
import '@/components/ui/reveal/reveal.css';

export const metadata: Metadata = {
  title: 'Ali Voryn | Software Engineer',
  description: 'Portfolio of Ali Voryn — Backend Engineering, Web3, and decentralized technologies.',
  applicationName: 'Ali Voryn Portfolio',
  robots: { index: true, follow: true }
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#020713',
  colorScheme: 'dark'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        {/* Scroll reveal hides elements until its script shows them; without scripts nothing may stay hidden. */}
        <noscript><style>{'[data-reveal],[data-reveal-item]{opacity:1!important;pointer-events:auto!important}'}</style></noscript>
      </head>
      <body>{children}</body>
    </html>
  );
}
