'use client';

import { useEffect } from 'react';
import { initAsciiRain } from '@/lib/effects/ascii-rain.js';
import { initCursorRing } from '@/lib/effects/cursor-ring.js';
import { initTypewriterGlitch } from '@/features/hero/typewriter-glitch.js';
import { initThemeLanguage } from '@/features/theme/theme-language.js';
import { initMobileMenu } from '@/components/layout/mobile-menu.js';
import { initNavScribble } from '@/components/layout/scribble-loop.js';
import { initSectionDots } from '@/components/ui/section-dots/section-dots.js';
import { initFloatingDocks } from '@/components/ui/floating-dock/floating-dock.js';
import { initScrollReveal } from '@/components/ui/reveal/scroll-reveal.js';
import { initCodeWindow } from '@/features/hero/code-window.js';
import { initHeroStats } from '@/features/hero/hero-stats.js';
import { initGlobeMesh } from '@/features/about/globe-mesh.js';
import { initSpotlightText } from '@/features/about/spotlight-text.js';
import { initCourseSearch } from '@/features/search/course-search.js';

type PortfolioWindow = Window & { __aliVorynEffectsInitialized?: boolean };

/** Isolates legacy canvas/DOM effects from the server-rendered React component tree. */
export function PortfolioEffects() {
  useEffect(() => {
    const appWindow = window as PortfolioWindow;
    if (appWindow.__aliVorynEffectsInitialized) return;
    appWindow.__aliVorynEffectsInitialized = true;

    initThemeLanguage();
    initMobileMenu();
    initNavScribble();
    initSectionDots();
    initFloatingDocks();
    initScrollReveal();
    initCursorRing();
    initAsciiRain();
    initTypewriterGlitch();
    initCodeWindow();
    initGlobeMesh();
    initSpotlightText();
    initCourseSearch();
    initHeroStats();
  }, []);

  return null;
}
