import { CourseShowcase } from '@/features/courses/components/CourseShowcase';
import { SectionTitle } from '@/components/ui/section-title/SectionTitle';
import { COURSE_CATEGORIES, COURSES } from '@/features/courses/courses.data';
import { sectionTitle } from '@/config/sections';

function AboutSection() {
  return (
    <section className="mock-section" id="about">
      <div className="section-inner about-layout">
        <div className="globe-wrap" data-reveal="end"><canvas id="aboutGlobe" role="img" aria-label="کرهٔ شبکه‌ای تعاملی" /></div>
        <div className="about-copy">
          <SectionTitle {...sectionTitle('about')} reveal="start" />
          <div className="spotlight-area" data-reveal="start" data-spotlight data-spotlight-radius="110">
            <div className="spotlight-base">
              <p data-fa="من Ali Voryn هستم؛ یک مهندس نرم‌افزار خودآموخته در مسیر تخصص در Backend Engineering، Web3 و فناوری‌های غیرمتمرکز. باور دارم مهندسی فراتر از نوشتن کد است؛ یعنی درک عمیق، تفکر سیستمی و تبدیل ایده‌های پیچیده به راهکارهای واقعی. مسیر من بر پایه یادگیری مستقل، ساختن، عبور از محدودیت‌ها و خلق آینده‌ای فراتر از افق‌های تعریف‌شده شکل گرفته است." data-en="I’m Ali Voryn, a self-taught software engineer specializing in Backend Engineering, Web3, and decentralized technologies. I believe engineering goes beyond writing code; it means deep understanding, systems thinking, and turning complex ideas into practical solutions. My path is shaped by independent learning, building, pushing past limits, and creating a future beyond defined horizons.">من Ali Voryn هستم؛ یک مهندس نرم‌افزار خودآموخته در مسیر تخصص در Backend Engineering، Web3 و فناوری‌های غیرمتمرکز. باور دارم مهندسی فراتر از نوشتن کد است؛ یعنی درک عمیق، تفکر سیستمی و تبدیل ایده‌های پیچیده به راهکارهای واقعی. مسیر من بر پایه یادگیری مستقل، ساختن، عبور از محدودیت‌ها و خلق آینده‌ای فراتر از افق‌های تعریف‌شده شکل گرفته است.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function CoursesSection() {
  return (
    <section className="mock-section" id="courses">
      <div className="section-inner">
        <SectionTitle {...sectionTitle('courses')} reveal="start" />
        <CourseShowcase courses={COURSES} categories={COURSE_CATEGORIES} />
      </div>
    </section>
  );
}

function CategoriesSection() {
  return (
    <section className="mock-section" id="categories">
      <div className="section-inner">
        <SectionTitle {...sectionTitle('categories')} reveal="start" />
        <div className="project-grid" aria-hidden="true">
          <article className="mock-project" data-reveal="end"><i className="project-art art-one" /><span className="mock-lines"><i /><i /></span></article>
          <article className="mock-project" data-reveal="end"><i className="project-art art-two" /><span className="mock-lines"><i /><i /></span></article>
          <article className="mock-project" data-reveal="end"><i className="project-art art-three" /><span className="mock-lines"><i /><i /></span></article>
        </div>
      </div>
    </section>
  );
}

function ExperienceSection() {
  return (
    <section className="mock-section" id="experience">
      <div className="section-inner">
        <SectionTitle {...sectionTitle('experience')} reveal="start" />
        <div className="timeline-skeleton" aria-hidden="true">
          <i className="timeline-track" data-reveal="fade" />
          {Array.from({ length: 3 }, (_, index) => <div className="timeline-item" data-reveal="start" key={index}><i className="timeline-dot" /><span className="mock-lines"><i /><i /><i /></span></div>)}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section className="mock-section" id="contact">
      <div className="section-inner">
        <SectionTitle {...sectionTitle('contact')} reveal="start" />
        <div className="contact-skeleton" data-reveal="end" data-reveal-group aria-hidden="true"><i data-reveal-item="start" /><i data-reveal-item="start" /><i data-reveal-item="start" /><i className="contact-send" data-reveal-item="start" /></div>
      </div>
    </section>
  );
}

export function PortfolioSections() {
  return <main className="mock-sections"><AboutSection /><CoursesSection /><CategoriesSection /><ExperienceSection /><ContactSection /></main>;
}
