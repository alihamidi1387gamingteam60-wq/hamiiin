import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteSettings } from '@/components/layout/SiteSettings';
import { HeroSection } from '@/features/hero/HeroSection';
import { PortfolioSections } from '@/app/_components/PortfolioSections';
import { ThemeDialog } from '@/features/theme/ThemeDialog';
import { CourseSearchDialog } from '@/features/search/CourseSearchDialog';
import { PortfolioEffects } from '@/app/_components/PortfolioEffects';
import { SectionDots } from '@/components/ui/section-dots/SectionDots';
import { HOME_SECTIONS } from '@/config/sections';

export default function HomePage() {
  return (
    <>
      <canvas id="asciiRain" aria-hidden="true" />
      <canvas id="cursorField" aria-hidden="true" />
      <SiteHeader />
      <SectionDots sections={HOME_SECTIONS} showAfter="home" ariaLabel="بخش‌های صفحه" />
      <SiteSettings />
      <HeroSection />
      <PortfolioSections />
      <ThemeDialog />
      <CourseSearchDialog />
      <PortfolioEffects />
    </>
  );
}
