import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        space: 'var(--page-bg)',
        accent: 'var(--accent)',
        crystal: 'var(--crystal)'
      },
      fontFamily: {
        // The families themselves are declared once, in src/app/globals.css.
        sans: ['var(--font-body)'],
        heading: ['var(--font-display)'],
        number: ['var(--font-number)'],
        mono: ['var(--font-mono)']
      }
    }
  },
  plugins: []
};

export default config;
