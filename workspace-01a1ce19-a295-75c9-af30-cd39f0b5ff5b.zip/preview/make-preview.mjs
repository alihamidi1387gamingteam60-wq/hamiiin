#!/usr/bin/env node
/**
 * Builds a single self-contained HTML snapshot of the portfolio:
 *   /home/user/preview/portfolio.html
 *
 * It runs the real production build, then inlines everything the page needs
 * (markup, compiled CSS, fonts, images and the client-side code) into one file
 * that opens anywhere without a server or network access.
 *
 * Usage:  node preview/make-preview.mjs            (build + snapshot)
 *         node preview/make-preview.mjs --no-build (reuse existing .next)
 *
 * Needs esbuild; it is installed into preview/node_modules on first run.
 */
import { execSync } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const project = resolve(here, '../ali-voryn-portfolio');
const output = join(here, 'portfolio.html');
const read = path => readFileSync(path, 'utf8');
const fail = message => { console.error(`make-preview: ${message}`); process.exit(1); };

if (!process.argv.includes('--no-build')) {
  execSync('npm run build', { cwd: project, stdio: 'inherit', env: { ...process.env, NEXT_TELEMETRY_DISABLED: '1' } });
}

// 1. Prerendered markup from the production build.
const htmlPath = join(project, '.next/server/app/index.html');
if (!existsSync(htmlPath)) fail('no production build found; run without --no-build');
const html = read(htmlPath);
const htmlTag = html.match(/<html[^>]*>/)?.[0] ?? fail('missing <html>');
const title = html.match(/<title>[^<]*<\/title>/)?.[0] ?? '';
const metas = (html.match(/<meta[^>]*>/g) ?? []).filter(tag => !/charSet/i.test(tag)).join('\n');
let body = html.match(/<body[^>]*>([\s\S]*)<\/body>/)?.[1] ?? fail('missing <body>');

// React may stream a Suspense boundary (the route's loading.tsx) out of line:
// a fallback marked by <template id="B:n">, the real content in a hidden
// <div id="S:n">, and an inline script that swaps them. Do that swap here, so
// the snapshot holds the final markup and needs none of those scripts.
for (const [segment, id, content] of [...body.matchAll(/<div hidden id="S:(\d+)">([\s\S]*?)<\/div>(?=<script>\$R)/g)]) {
  const fallback = new RegExp(`<!--\\$\\?--><template id="B:${id}"></template>[\\s\\S]*?<!--/\\$-->`);
  if (!fallback.test(body)) fail(`streamed segment S:${id} has no matching fallback`);
  body = body.replace(segment, () => '').replace(fallback, () => `<!--$-->${content}<!--/$-->`);
}
body = body.replace(/<script\b[\s\S]*?<\/script>/g, '');
if (/<template id="B:|<div hidden id="S:/.test(body)) fail('unresolved streamed Suspense boundary in the prerendered page');

// 2. Compiled CSS, with the self-hosted fonts embedded as data URIs.
const cssLinks = [...html.matchAll(/<link rel="stylesheet" href="([^"]+)"/g)].map(match => match[1]);
if (!cssLinks.length) fail('no stylesheet found in build output');
let fontCount = 0;
const css = cssLinks
  .map(href => read(join(project, '.next', href.replace(/^\/_next\//, ''))))
  .join('\n')
  .replace(/url\((['"]?)(\/fonts\/[^'")]+)\1\)/g, (_, _quote, fontPath) => {
    fontCount++;
    const data = readFileSync(join(project, 'public', fontPath)).toString('base64');
    return `url(data:font/woff2;base64,${data})`;
  })
  // Pictures the stylesheets point at (the signature GIF and its still frame).
  .replace(/url\((['"]?)(\/brand\/[^'")]+\.(gif|png))\1\)/g, (_, _quote, imagePath, type) => {
    const data = readFileSync(join(project, 'public', imagePath)).toString('base64');
    return `url(data:image/${type};base64,${data})`;
  });

// 3. Images. next/image points at the /_next/image optimiser, which does not
//    exist offline, so every image it references is embedded as a data URI
//    (scaled down to what a card needs, to keep the file small).
const projectRequire = createRequire(join(project, 'package.json'));
const sharp = projectRequire('sharp');
const SNAPSHOT_IMAGE_WIDTH = 720;
const imagePaths = [...new Set([...body.matchAll(/\/_next\/image\?url=([^&"\s]+)/g)].map(match => decodeURIComponent(match[1])))];
const images = {};
for (const imagePath of imagePaths) {
  const file = join(project, 'public', imagePath);
  if (!existsSync(file)) fail(`image not found: public${imagePath}`);
  const data = await sharp(file).resize({ width: SNAPSHOT_IMAGE_WIDTH, withoutEnlargement: true }).webp({ quality: 80 }).toBuffer();
  images[imagePath] = `data:image/webp;base64,${data.toString('base64')}`;
}
// The prerendered <img> tags are replaced as soon as the script below renders;
// drop their optimiser URLs so the browser never requests them.
body = body.replace(/<img\b[^>]*\/_next\/image[^>]*>/g, tag => tag.replace(/\s(?:src|srcSet|srcset)="[^"]*"/g, ''));

// 4. Client-side code: the same modules the real app runs, bundled into one
//    script. A snapshot has no Next.js runtime to hydrate the page, so the
//    client components are mounted here by hand — keep this list in step with
//    the client components used on the page (src/app/page.tsx).
if ((body.match(/class="course-showcase"/g) ?? []).length !== 1) fail('expected exactly one .course-showcase in the prerendered page');

const entry = `
import { createRoot } from 'react-dom/client';
import { PortfolioEffects } from '@/app/_components/PortfolioEffects';
import { CourseShowcase } from '@/features/courses/components/CourseShowcase';
import { COURSE_CATEGORIES, COURSES } from '@/features/courses/courses.data';

// Snapshot-only: keep in-page "#section" links inside this document even when
// it is shown in an embedded viewer.
document.addEventListener('click', event => {
  const link = event.target instanceof Element ? event.target.closest('a[href^="#"]') : null;
  if (!link) return;
  const target = document.getElementById(link.getAttribute('href').slice(1));
  if (!target) return;
  event.preventDefault();
  target.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

// Boots the DOM effects (theme, language, canvases, search); renders nothing.
createRoot(document.createElement('div')).render(<PortfolioEffects />);

// Same props as in src/components/sections/PortfolioSections.tsx.
const prerendered = document.querySelector('.course-showcase');
const mount = document.createElement('div');
prerendered.replaceWith(mount);
createRoot(mount).render(<CourseShowcase courses={COURSES} categories={COURSE_CATEGORIES} />);
`;

// Stand-in for next/image: a plain <img> fed from the embedded data URIs.
const imageShim = `
import { createElement } from 'react';
const images = ${JSON.stringify(images)};
export default function Image({ src, alt, width, height, className, draggable }) {
  return createElement('img', { src: images[src] ?? src, alt, width, height, className, draggable, decoding: 'async' });
}
`;

if (!existsSync(join(here, 'node_modules/esbuild'))) {
  execSync('npm install --no-audit --no-fund', { cwd: here, stdio: 'inherit' });
}
const { build } = await import('esbuild');
const bundle = await build({
  stdin: { contents: entry, resolveDir: project, sourcefile: 'snapshot-entry.tsx', loader: 'tsx' },
  absWorkingDir: project,
  tsconfig: join(project, 'tsconfig.json'),
  bundle: true,
  write: false,
  format: 'iife',
  platform: 'browser',
  target: 'es2022',
  minify: true,
  legalComments: 'none',
  jsx: 'automatic',
  define: { 'process.env.NODE_ENV': '"production"' },
  loader: { '.css': 'empty' }, // styles already come from the compiled CSS above
  logOverride: { 'module-level-directive': 'silent' }, // 'use client' means nothing outside Next.js
  plugins: [{
    name: 'next-image-shim',
    setup(builder) {
      builder.onResolve({ filter: /^next\/image$/ }, () => ({ path: 'next-image-shim', namespace: 'snapshot' }));
      builder.onLoad({ filter: /.*/, namespace: 'snapshot' }, () => ({ contents: imageShim, loader: 'js', resolveDir: project }));
    }
  }]
});
const script = bundle.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');

const stamp = new Date().toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
const page = `<!DOCTYPE html>
<!-- Snapshot of ali-voryn-portfolio, generated ${stamp} by preview/make-preview.mjs. Do not edit by hand. -->
${htmlTag}
<head>
<meta charset="utf-8">
${metas}
${title}
<style>${css}</style>
</head>
<body>${body}<script>${script}</script></body>
</html>
`;

writeFileSync(output, page);
console.log(`make-preview: wrote ${output} (${(page.length / 1024).toFixed(0)} KB, ${fontCount} fonts, ${imagePaths.length} images, ${stamp})`);
